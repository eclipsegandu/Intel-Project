/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { ParticleCanvas } from './components/ParticleCanvas';
import { HeroSection } from './components/HeroSection';
import { OriginSection } from './components/OriginSection';
import { MeetTheLightsSection } from './components/MeetTheLightsSection';
import { ComparisonSection } from './components/ComparisonSection';
import { TwoRoomsSection } from './components/TwoRoomsSection';
import { QuizSection } from './components/QuizSection';
import { EndingSection } from './components/EndingSection';

export default function App() {
  const [reducedMotion, setReducedMotion] = useState(false);

  const scrollToSection = (sectionId: string) => {
    const el = document.getElementById(sectionId);
    if (el) {
      el.scrollIntoView({ behavior: reducedMotion ? 'auto' : 'smooth' });
    }
  };

  const handleProductSelect = (productId: 'ultra' | 'core') => {
    // Navigate to Rooms and activate the corresponding room
    const roomsEl = document.getElementById('rooms');
    if (roomsEl) {
      roomsEl.scrollIntoView({ behavior: reducedMotion ? 'auto' : 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-[#08090c] text-[#f4f4f5] selection:bg-[#ffad42] selection:text-[#08090c] relative font-sans">
      {/* Background Ember Particles */}
      <ParticleCanvas reducedMotion={reducedMotion} />

      {/* Top Bar Navigation */}
      <Navbar
        onNavigate={scrollToSection}
        reducedMotion={reducedMotion}
        onToggleReducedMotion={() => setReducedMotion(!reducedMotion)}
      />

      <main className="relative z-10">
        {/* Page 1: Cinematic Hero */}
        <HeroSection
          onEnterStory={() => scrollToSection('origin')}
          onExploreLights={() => scrollToSection('lights')}
          reducedMotion={reducedMotion}
        />

        {/* Page 2: The Origin — One Ember */}
        <OriginSection
          onContinueToLights={() => scrollToSection('lights')}
          reducedMotion={reducedMotion}
        />

        {/* Page 3: Meet the Two Lights */}
        <MeetTheLightsSection
          onSelectProduct={handleProductSelect}
          onGoToComparison={() => scrollToSection('comparison')}
          reducedMotion={reducedMotion}
        />

        {/* Page 4: Interactive Comparison — Same Origin, Different Reach */}
        <ComparisonSection reducedMotion={reducedMotion} />

        {/* Page 5: Two Rooms, Two Different Worlds */}
        <TwoRoomsSection reducedMotion={reducedMotion} />

        {/* Page 6: Find Your Light — Interactive Recommendation */}
        <QuizSection
          onExploreProduct={(prod) => {
            handleProductSelect(prod);
          }}
          reducedMotion={reducedMotion}
        />

        {/* Page 7: Final Cinematic Ending */}
        <EndingSection
          onSelectUltra={() => handleProductSelect('ultra')}
          onSelectCore={() => handleProductSelect('core')}
          onRestart={() => scrollToSection('quiz')}
          reducedMotion={reducedMotion}
        />
      </main>
    </div>
  );
}
