/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface ProcessorSpec {
  id: 'ultra' | 'core';
  name: string;
  tagline: string;
  metaphorName: string;
  metaphorType: 'chandelier' | 'lantern';
  shortDescription: string;
  longDescription: string;
  heroHeadline: string;
  roomHeadline: string;
  roomSubtext: string;
  targetWorkload: string;
  manufacturing: string;
  cpu: {
    maxCores: number;
    description: string;
    filaments: number;
  };
  npu: {
    maxTops: number;
    description: string;
    sparkScale: number;
  };
  graphics: {
    cores: number;
    architecture: string;
    lightSpread: string;
  };
  connectivity: {
    wifi: string;
    thunderbolt: string;
  };
  keyWorkloads: string[];
}

export const CAMPAIGN_DATA = {
  campaignTitle: 'BORN IN THE SAME FLAME',
  heroSubtitle: 'One origin. Two expressions. Find the light that fits your world.',
  sharedFoundation: {
    processNode: 'Intel 18A Process Technology',
    description: 'Forged from the same molecular precision. A single technological breakthrough shaped into two distinct expressions of computing light.',
    connectivity: ['Wi-Fi 7 Ultra-Low Latency', 'Thunderbolt™ 4 Universal High-Speed I/O']
  },
  products: {
    ultra: {
      id: 'ultra',
      name: 'Intel® Core™ Ultra Series 3',
      tagline: 'FOR WORLDS THAT DEMAND MORE.',
      metaphorName: 'The Crystal Chandelier',
      metaphorType: 'chandelier',
      shortDescription: 'For creators, builders, and players who want room for ambitious ideas.',
      longDescription: 'Like an intricate crystal chandelier radiating countless refractions across a grand hall, Intel Core Ultra Series 3 delivers expansive headroom for high-throughput computing, multi-layer rendering, neural workloads, and uncompromising gaming.',
      heroHeadline: 'FOR WORLDS THAT DEMAND MORE.',
      roomHeadline: 'WHEN YOUR IDEAS NEED THE WHOLE ROOM.',
      roomSubtext: 'Explore a world of creative possibilities with Intel Core Ultra Series 3.',
      targetWorkload: 'Ambitious 4K/8K video editing, real-time 3D viewport rendering, local AI generation, and immersive high-frame gaming.',
      manufacturing: 'Intel 18A Architecture',
      cpu: {
        maxCores: 16,
        description: 'Up to 16 Cores for heavy multi-threaded execution',
        filaments: 16
      },
      npu: {
        maxTops: 50,
        description: 'Up to 50 TOPS Dedicated NPU for on-device AI accelerators',
        sparkScale: 1.0
      },
      graphics: {
        cores: 12,
        architecture: 'Up to 12 Xe3 Graphics Cores',
        lightSpread: 'Omnidirectional ray scatter across expansive multi-monitor canvas'
      },
      connectivity: {
        wifi: 'Wi-Fi 7 (Up to 5 Gbps)',
        thunderbolt: 'Thunderbolt™ 4 (Up to 40 Gbps bi-directional)'
      },
      keyWorkloads: [
        'Multi-track 4K/8K Video Timelines',
        '3D Modeling & Complex Scene Shading',
        'Local LLM & Diffusion Model Generation',
        'Competitive High-Refresh Gaming'
      ]
    } as ProcessorSpec,
    core: {
      id: 'core',
      name: 'Intel® Core™ Series 3',
      tagline: 'FOR THE THINGS THAT MOVE YOU FORWARD.',
      metaphorName: 'The Amber Lantern',
      metaphorType: 'lantern',
      shortDescription: "Focused performance for everyday work, learning, and life's digital moments.",
      longDescription: 'Like an artisan hand-blown amber lantern casting a calm, warm, and intentional pool of light onto your desk, Intel Core Series 3 delivers dependable, power-efficient responsiveness for academic writing, seamless video meetings, and agile multitasking.',
      heroHeadline: 'FOR THE THINGS THAT MOVE YOU FORWARD.',
      roomHeadline: 'WHEN THE RIGHT LIGHT IS ALL YOU NEED.',
      roomSubtext: 'Make space for everyday productivity with Intel Core Series 3.',
      targetWorkload: 'All-day office workflows, research, crisp video conferences, seamless document multitasking, and streaming.',
      manufacturing: 'Intel 18A Architecture',
      cpu: {
        maxCores: 6,
        description: 'Up to 6 Cores optimized for thermal efficiency and snappy responsiveness',
        filaments: 6
      },
      npu: {
        maxTops: 17,
        description: 'Up to 17 TOPS NPU for background noise removal, gaze correction, and smart assistant features',
        sparkScale: 0.55
      },
      graphics: {
        cores: 2,
        architecture: 'Up to 2 Xe3 Graphics Cores',
        lightSpread: 'Focused desktop illumination for dual-display clarity and multimedia'
      },
      connectivity: {
        wifi: 'Wi-Fi 7 (Up to 5 Gbps)',
        thunderbolt: 'Thunderbolt™ 4 (Up to 40 Gbps bi-directional)'
      },
      keyWorkloads: [
        'Fluid Document Editing & Spreadsheet Modeling',
        'AI Studio & Live Meeting Camera Framing',
        'Multi-tab Research & Web Applications',
        'Ultra-quiet, Long Battery Life Efficiency'
      ]
    } as ProcessorSpec
  },
  disclaimer: 'Campaign concept demonstration. Processor specifications represent maximum potential architectural configurations; actual specifications, performance, features, and availability vary by SKU, system design, and platform implementation. Wi-Fi 7 and Thunderbolt 4 require compatible OS and hardware. For educational and conceptual advertising purposes.'
};

export interface QuizQuestion {
  id: number;
  question: string;
  subtitle: string;
  options: {
    id: string;
    label: string;
    description: string;
    points: { ultra: number; core: number };
  }[];
}

export const QUIZ_QUESTIONS: QuizQuestion[] = [
  {
    id: 1,
    question: 'What do you spend most of your time doing?',
    subtitle: 'Consider your core everyday applications and primary intent.',
    options: [
      {
        id: 'q1-creative',
        label: 'Demanding Creative & Visual Work',
        description: 'High-resolution video editing, 3D modeling, rendering, and visual effects.',
        points: { ultra: 3, core: 0 }
      },
      {
        id: 'q1-gaming',
        label: 'Gaming & High-Throughput Computing',
        description: 'Demanding modern titles, simulation, and graphics-intensive workflows.',
        points: { ultra: 3, core: 0 }
      },
      {
        id: 'q1-productivity',
        label: 'Studying, Research & Daily Communication',
        description: 'Writing, video calls, browser research, productivity suites, and streaming.',
        points: { ultra: 0, core: 3 }
      },
      {
        id: 'q1-mixed',
        label: 'A Flexible Balance of Both',
        description: 'General productivity by day, with occasional photo editing or casual games.',
        points: { ultra: 1, core: 2 }
      }
    ]
  },
  {
    id: 2,
    question: 'What matters most to you in your device?',
    subtitle: 'Choose the quality that defines an ideal day at work.',
    options: [
      {
        id: 'q2-headroom',
        label: 'Maximum Creative Headroom & Graphics Power',
        description: 'Never waiting on renders, simultaneous multi-app execution, and peak TOPS.',
        points: { ultra: 3, core: 0 }
      },
      {
        id: 'q2-efficiency',
        label: 'Reliable Everyday Productivity & Efficiency',
        description: 'Instant wake, whisper-quiet operation, cool lap thermals, and dependable flow.',
        points: { ultra: 0, core: 3 }
      },
      {
        id: 'q2-balance',
        label: 'A Harmonious Balance Across Activities',
        description: 'Smooth multitasking with enough power to grow when new challenges arise.',
        points: { ultra: 1, core: 1 }
      }
    ]
  },
  {
    id: 3,
    question: 'Which workspace feels closer to yours?',
    subtitle: 'Reflect on your physical and digital atmosphere.',
    options: [
      {
        id: 'q3-studio',
        label: 'An Ambitious Creative Studio',
        description: 'Multiple monitors, external drives, editing decks, and open timelines.',
        points: { ultra: 3, core: 0 }
      },
      {
        id: 'q3-desk',
        label: 'A Calm, Focused Desk',
        description: 'A clean notebook, coffee cup, single laptop screen, and uninterrupted concentration.',
        points: { ultra: 0, core: 3 }
      }
    ]
  },
  {
    id: 4,
    question: 'How would you describe your typical workload?',
    subtitle: 'Peak throughput versus continuous efficiency.',
    options: [
      {
        id: 'q4-heavy',
        label: 'Heavy, Sustained & Resource-Intensive',
        description: 'Complex compiles, rendering queues, RAW batch processing, and AI generation.',
        points: { ultra: 3, core: 0 }
      },
      {
        id: 'q4-daily',
        label: 'Steady, Agile & Everyday Applications',
        description: 'Docs, spreadsheets, cloud apps, video conferences, and streaming playback.',
        points: { ultra: 0, core: 3 }
      },
      {
        id: 'q4-varied',
        label: 'Different Workloads Throughout the Day',
        description: 'Varies between focused writing sessions and bursts of heavier tasks.',
        points: { ultra: 1, core: 2 }
      }
    ]
  }
];
