/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import type { Variants, TargetAndTransition } from 'motion/react';

// Editorial luxury cubic-bezier easing curve
export const MOTION_EASE = [0.16, 1, 0.3, 1] as const;

export interface MotionCustomProps {
  reducedMotion?: boolean;
  duration?: number;
  delay?: number;
  staggerChildren?: number;
  delayChildren?: number;
  yOffset?: number;
}

/**
 * Returns consistent transition parameters respecting reducedMotion state.
 * Sets duration to 0 when reducedMotion is true, otherwise defaults to 0.8s.
 */
export const getRevealTransition = (reducedMotion: boolean = false, duration: number = 0.8) => ({
  duration: reducedMotion ? 0 : duration,
  ease: MOTION_EASE
});

/**
 * Staggered container variant for header groups and card grids.
 */
export const staggerContainerVariants: Variants = {
  hidden: (custom?: MotionCustomProps): TargetAndTransition => ({
    opacity: custom?.reducedMotion ? 1 : 0
  }),
  visible: (custom?: MotionCustomProps): TargetAndTransition => ({
    opacity: 1,
    transition: {
      staggerChildren: custom?.reducedMotion ? 0 : (custom?.staggerChildren ?? 0.16),
      delayChildren: custom?.reducedMotion ? 0 : (custom?.delayChildren ?? 0.08)
    }
  })
};

/**
 * Fade and slide up variant for section titles, kickers, and subtitles.
 * Ensures 'transition={{ duration: reducedMotion ? 0 : 0.8 }}' is respected.
 */
export const fadeSlideUpVariants: Variants = {
  hidden: (custom?: MotionCustomProps): TargetAndTransition => ({
    opacity: custom?.reducedMotion ? 1 : 0,
    y: custom?.reducedMotion ? 0 : (custom?.yOffset ?? 28)
  }),
  visible: (custom?: MotionCustomProps): TargetAndTransition => ({
    opacity: 1,
    y: 0,
    transition: {
      duration: custom?.reducedMotion ? 0 : (custom?.duration ?? 0.8),
      delay: custom?.reducedMotion ? 0 : (custom?.delay ?? 0),
      ease: MOTION_EASE
    }
  })
};

/**
 * Card reveal variant with subtle vertical translation and micro-scale settling.
 */
export const cardRevealVariants: Variants = {
  hidden: (custom?: MotionCustomProps): TargetAndTransition => ({
    opacity: custom?.reducedMotion ? 1 : 0,
    y: custom?.reducedMotion ? 0 : 24,
    scale: custom?.reducedMotion ? 1 : 0.98
  }),
  visible: (custom?: MotionCustomProps): TargetAndTransition => ({
    opacity: 1,
    y: 0,
    scale: 1,
    transition: {
      duration: custom?.reducedMotion ? 0 : (custom?.duration ?? 0.8),
      delay: custom?.reducedMotion ? 0 : (custom?.delay ?? 0),
      ease: MOTION_EASE
    }
  })
};

/**
 * Scale and fade variant for modal windows and focused elements.
 */
export const scaleFadeVariants: Variants = {
  hidden: (custom?: MotionCustomProps): TargetAndTransition => ({
    opacity: custom?.reducedMotion ? 1 : 0,
    scale: custom?.reducedMotion ? 1 : 0.95
  }),
  visible: (custom?: MotionCustomProps): TargetAndTransition => ({
    opacity: 1,
    scale: 1,
    transition: {
      duration: custom?.reducedMotion ? 0 : (custom?.duration ?? 0.8),
      ease: MOTION_EASE
    }
  })
};

/**
 * Atmospheric breathing pulse variant for glowing embers, sparks, and filaments.
 */
export const emberPulseVariants: Variants = {
  idle: (custom?: MotionCustomProps): TargetAndTransition => ({
    scale: 1,
    opacity: 0.85
  }),
  pulsing: (custom?: MotionCustomProps): TargetAndTransition => ({
    scale: custom?.reducedMotion ? 1 : 1.06,
    opacity: 1,
    transition: {
      duration: custom?.reducedMotion ? 0 : 3.5,
      repeat: custom?.reducedMotion ? 0 : Infinity,
      repeatType: 'reverse',
      ease: 'easeInOut'
    }
  })
};
