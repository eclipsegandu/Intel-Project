/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { ChevronDown, ArrowRight } from 'lucide-react';
import { sound } from '../utils/audio';
import { CinematicHeader } from './CinematicHeader';

interface HeroSectionProps {
  onEnterStory: () => void;
  onExploreLights: () => void;
  reducedMotion?: boolean;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onEnterStory,
  onExploreLights,
  reducedMotion = false
}) => {
  const [emberIntensity, setEmberIntensity] = useState(1);
  const [isSparking, setIsSparking] = useState(false);

  const handleEmberClick = () => {
    sound.playAmberWarmth(240);
    setIsSparking(true);
    setEmberIntensity((prev) => (prev >= 1.6 ? 1 : prev + 0.3));
    setTimeout(() => setIsSparking(false), 800);
  };

  return (
    <section
      id="hero"
      className="relative min-h-screen w-full flex flex-col items-center justify-center px-6 sm:px-12 overflow-hidden bg-[#08090c]"
    >
      {/* Background Distant Furnace Glow */}
      <div
        className="pointer-events-none absolute inset-0 flex items-center justify-center overflow-hidden"
        aria-hidden="true"
      >
        {/* Soft deep radial heat wash */}
        <div
          className="w-[800px] h-[800px] rounded-full blur-[140px] opacity-25 transition-opacity duration-1000"
          style={{
            background: 'radial-gradient(circle, #ffad42 0%, #ff5500 35%, transparent 70%)',
            transform: `scale(${emberIntensity})`
          }}
        />
        <div className="absolute -bottom-40 w-[1200px] h-[300px] bg-gradient-to-t from-[#ff8c00]/15 via-[#ffad42]/5 to-transparent blur-[100px]" />
      </div>

      {/* Main Content Container */}
      <div className="relative z-10 max-w-5xl mx-auto text-center flex flex-col items-center pt-20 pb-16">
        {/* Floating Molten Ember Interactive Centerpiece */}
        <div
          className="relative my-6 sm:my-8 cursor-pointer group select-none"
          onClick={handleEmberClick}
          role="button"
          tabIndex={0}
          onKeyDown={(e) => {
            if (e.key === 'Enter' || e.key === ' ') {
              handleEmberClick();
            }
          }}
          aria-label="Interactive molten ember. Click to ignite energy."
        >
          {/* Pulsing Heat Rings */}
          <div
            className={`absolute -inset-8 rounded-full border border-[#ffad42]/30 transition-all duration-700 pointer-events-none ${
              isSparking ? 'scale-150 opacity-0' : 'scale-100 opacity-60 animate-ping'
            }`}
          />
          <div className="absolute -inset-16 rounded-full bg-radial from-[#ffad42]/30 via-transparent to-transparent blur-xl pointer-events-none group-hover:scale-125 transition-transform duration-500" />

          {/* Core Molten Glass Ember SVG */}
          <div className="relative w-32 h-32 sm:w-40 sm:h-40 flex items-center justify-center">
            <svg
              viewBox="0 0 160 160"
              className="w-full h-full drop-shadow-[0_0_35px_rgba(255,173,66,0.8)] group-hover:drop-shadow-[0_0_55px_rgba(255,190,90,1)] transition-all duration-300"
            >
              <defs>
                <radialGradient id="emberGlow" cx="50%" cy="50%" r="50%">
                  <stop offset="0%" stopColor="#ffffff" stopOpacity="1" />
                  <stop offset="25%" stopColor="#ffefd0" stopOpacity="0.95" />
                  <stop offset="55%" stopColor="#ffad42" stopOpacity="0.85" />
                  <stop offset="85%" stopColor="#ff5500" stopOpacity="0.7" />
                  <stop offset="100%" stopColor="#8b1e00" stopOpacity="0" />
                </radialGradient>
                <filter id="liquidDisplace">
                  <feTurbulence type="fractalNoise" baseFrequency="0.04" numOctaves="3" result="noise" />
                  <feDisplacementMap in="SourceGraphic" in2="noise" scale="6" />
                </filter>
              </defs>

              {/* Molten Outer Droplet */}
              <circle
                cx="80"
                cy="80"
                r="64"
                fill="url(#emberGlow)"
                className="animate-ember"
                filter="url(#liquidDisplace)"
              />

              {/* Inner Radiant Core */}
              <circle cx="80" cy="80" r="28" fill="#ffffff" opacity="0.9" className="animate-pulse" />

              {/* Subtle Swirling Molten Strands */}
              <path
                d="M50,80 Q80,50 110,80 T130,95"
                stroke="#fff4dc"
                strokeWidth="2.5"
                fill="none"
                opacity="0.8"
                strokeLinecap="round"
              />
              <path
                d="M60,95 Q80,110 105,75"
                stroke="#ffb45b"
                strokeWidth="2"
                fill="none"
                opacity="0.6"
                strokeLinecap="round"
              />
            </svg>
          </div>

          <p className="mt-2 text-[11px] uppercase tracking-widest text-[#a1a1aa] group-hover:text-[#ffad42] transition-colors">
            Tap to ignite energy
          </p>
        </div>

        {/* Cinematic Framer Motion Staggered Header */}
        <CinematicHeader
          as="h1"
          reducedMotion={reducedMotion}
          kicker={
            <>
              <span>Intel Architecture & Design</span>
              <span className="text-[#a1a1aa]" aria-hidden="true">·</span>
              <span>A Tale of Two Lights</span>
            </>
          }
          headline={
            <>
              BORN IN THE SAME FLAME<span className="text-[#ffad42]">.</span>
            </>
          }
          subtitle="One origin. Two expressions. Find the light that fits your world."
          actions={
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 w-full sm:w-auto">
              <button
                onClick={() => {
                  sound.playClick();
                  onEnterStory();
                }}
                className="w-full sm:w-auto px-8 py-3.5 text-xs sm:text-sm font-semibold tracking-widest uppercase text-[#08090c] bg-[#ffad42] hover:bg-[#ffbe5b] rounded transition-all duration-200 shadow-[0_0_25px_rgba(255,173,66,0.35)] hover:shadow-[0_0_35px_rgba(255,173,66,0.6)] hover:-translate-y-0.5 cursor-pointer flex items-center justify-center gap-2 whitespace-nowrap"
              >
                <span>Enter The Story</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={() => {
                  sound.playClick();
                  onExploreLights();
                }}
                className="w-full sm:w-auto px-8 py-3.5 text-xs sm:text-sm font-semibold tracking-widest uppercase text-[#f4f4f5] bg-white/5 hover:bg-white/10 border border-white/10 hover:border-white/20 rounded transition-all duration-200 cursor-pointer whitespace-nowrap"
              >
                Explore The Two Lights
              </button>
            </div>
          }
        />
      </div>

      {/* Subtle Scroll Indicator */}
      <div className="relative z-10 bottom-6 sm:bottom-8 flex flex-col items-center gap-2 text-[#a1a1aa]/60 hover:text-[#ffad42] transition-colors cursor-pointer select-none">
        <button
          onClick={onEnterStory}
          className="flex flex-col items-center gap-1 group cursor-pointer"
          aria-label="Scroll down to begin story"
        >
          <span className="text-[10px] tracking-[0.25em] uppercase font-medium">Scroll to Discover</span>
          <ChevronDown className="w-4 h-4 animate-bounce group-hover:text-[#ffad42]" />
        </button>
      </div>
    </section>
  );
};
