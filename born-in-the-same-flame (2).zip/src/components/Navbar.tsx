/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Volume2, VolumeX, Menu, X, Sparkles } from 'lucide-react';
import { sound } from '../utils/audio';

interface NavbarProps {
  onNavigate: (sectionId: string) => void;
  reducedMotion: boolean;
  onToggleReducedMotion: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  onNavigate,
  reducedMotion,
  onToggleReducedMotion
}) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMuted, setIsMuted] = useState(true);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 40);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleAudioToggle = () => {
    const soundActive = sound.toggleMute();
    setIsMuted(!soundActive);
  };

  const navLinks = [
    { id: 'origin', label: 'The Origin' },
    { id: 'lights', label: 'The Two Lights' },
    { id: 'comparison', label: 'Comparison' },
    { id: 'rooms', label: 'The Two Rooms' },
    { id: 'quiz', label: 'Find Your Light' }
  ];

  const handleLinkClick = (id: string) => {
    sound.playClick();
    onNavigate(id);
    setMobileMenuOpen(false);
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-[#08090c]/90 backdrop-blur-md border-b border-white/5 py-3'
          : 'bg-transparent py-5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 sm:px-8 flex items-center justify-between gap-8">
        {/* Zone 1: Single text element wordmark */}
        <a
          href="#hero"
          onClick={(e) => {
            e.preventDefault();
            handleLinkClick('hero');
          }}
          className="text-base sm:text-lg font-semibold tracking-wider text-white hover:text-[#ffad42] transition-colors whitespace-nowrap shrink-0 flex items-center gap-2"
        >
          <span className="w-2 h-2 rounded-full bg-[#ffad42] inline-block shadow-[0_0_10px_#ffad42]" />
          <span>BORN IN THE SAME FLAME</span>
        </a>

        {/* Zone 2: 4-5 clean single-line text navigation links */}
        <nav className="hidden lg:flex items-center gap-8 text-xs tracking-widest uppercase font-medium text-[#a1a1aa]">
          {navLinks.map((link) => (
            <button
              key={link.id}
              onClick={() => handleLinkClick(link.id)}
              className="hover:text-white transition-colors cursor-pointer whitespace-nowrap shrink-0 py-1"
            >
              {link.label}
            </button>
          ))}
        </nav>

        {/* Zone 3: 1 primary action cluster */}
        <div className="flex items-center gap-4 shrink-0">
          {/* Ambient Soundscape Toggle */}
          <button
            onClick={handleAudioToggle}
            className={`p-2 rounded-lg border text-xs transition-colors cursor-pointer flex items-center gap-2 ${
              !isMuted
                ? 'border-[#ffad42]/40 text-[#ffad42] bg-[#ffad42]/10'
                : 'border-white/10 text-[#a1a1aa] hover:text-white hover:border-white/20'
            }`}
            title={isMuted ? 'Turn on ambient soundscape' : 'Mute soundscape'}
            aria-label={isMuted ? 'Turn on ambient soundscape' : 'Mute soundscape'}
          >
            {!isMuted ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            <span className="hidden sm:inline text-[11px] tracking-wider uppercase">
              {!isMuted ? 'Forge Sound' : 'Sound Off'}
            </span>
          </button>

          {/* Primary Action Button */}
          <button
            onClick={() => handleLinkClick('lights')}
            className="hidden sm:inline-flex px-4 py-2 text-xs font-semibold tracking-widest uppercase text-[#08090c] bg-[#ffad42] hover:bg-[#ffbe5b] rounded transition-all shadow-[0_0_20px_rgba(255,173,66,0.3)] hover:shadow-[0_0_30px_rgba(255,173,66,0.5)] cursor-pointer whitespace-nowrap shrink-0"
          >
            Explore The Lights
          </button>

          {/* Mobile Menu Toggle */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-2 text-[#a1a1aa] hover:text-white"
            aria-label="Toggle navigation menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#08090c]/98 border-b border-white/10 px-6 py-6 transition-all">
          <div className="flex flex-col gap-4 text-sm font-medium tracking-wider uppercase text-[#a1a1aa]">
            {navLinks.map((link) => (
              <button
                key={link.id}
                onClick={() => handleLinkClick(link.id)}
                className="text-left py-2 hover:text-white transition-colors cursor-pointer border-b border-white/5"
              >
                {link.label}
              </button>
            ))}
            <div className="pt-3 flex items-center justify-between">
              <button
                onClick={onToggleReducedMotion}
                className="text-xs text-[#a1a1aa] hover:text-white flex items-center gap-2 cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>Motion: {reducedMotion ? 'Reduced' : 'Full'}</span>
              </button>
              <button
                onClick={() => handleLinkClick('quiz')}
                className="px-4 py-2 text-xs font-semibold tracking-wider uppercase text-[#08090c] bg-[#ffad42] rounded cursor-pointer"
              >
                Find Your Light
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
