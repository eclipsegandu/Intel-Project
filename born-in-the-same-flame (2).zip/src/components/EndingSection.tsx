/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { ArrowUp, Sparkles, ExternalLink, RefreshCw } from 'lucide-react';
import { CAMPAIGN_DATA } from '../data/campaignConfig';
import { sound } from '../utils/audio';
import { CinematicHeader } from './CinematicHeader';

interface EndingSectionProps {
  onSelectUltra: () => void;
  onSelectCore: () => void;
  onRestart: () => void;
  reducedMotion?: boolean;
}

export const EndingSection: React.FC<EndingSectionProps> = ({
  onSelectUltra,
  onSelectCore,
  onRestart,
  reducedMotion = false
}) => {
  const [activeModalProduct, setActiveModalProduct] = useState<'ultra' | 'core' | null>(null);

  const ultra = CAMPAIGN_DATA.products.ultra;
  const core = CAMPAIGN_DATA.products.core;

  const scrollToTop = () => {
    sound.playClick();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer
      id="ending"
      className="relative min-h-screen w-full py-28 px-6 sm:px-12 bg-[#08090c] border-t border-white/5 flex flex-col justify-between overflow-hidden"
    >
      {/* Background Dark Artisan Studio Ambient Wash */}
      <div className="pointer-events-none absolute inset-0 overflow-hidden" aria-hidden="true">
        {/* Left pool: Cool Crystalline light */}
        <div className="absolute top-1/3 left-1/4 -translate-x-1/2 w-[500px] h-[500px] rounded-full bg-[#cbe5fe]/10 blur-[140px]" />
        {/* Right pool: Warm Amber light */}
        <div className="absolute top-1/3 right-1/4 translate-x-1/2 w-[500px] h-[500px] rounded-full bg-[#ffad42]/10 blur-[140px]" />
        {/* Distant hearth flame */}
        <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[800px] h-[250px] bg-gradient-to-t from-[#ff5500]/10 via-transparent to-transparent blur-[100px]" />
      </div>

      <div className="relative z-10 max-w-5xl mx-auto w-full text-center my-auto">
        {/* Visual Dual Light Presentation Side-by-Side */}
        <div className="relative max-w-lg mx-auto h-48 mb-8 flex items-center justify-around">
          {/* Small Chandelier Silhouette with refractive halo */}
          <div
            className="flex flex-col items-center group cursor-pointer"
            onClick={() => {
              sound.playCrystalChime(750);
              setActiveModalProduct('ultra');
            }}
          >
            <div className="w-24 h-24 rounded-full bg-[#cbe5fe]/10 border border-[#cbe5fe]/30 flex items-center justify-center shadow-[0_0_30px_rgba(203,229,254,0.3)] group-hover:scale-110 transition-transform">
              <svg viewBox="0 0 60 60" className="w-14 h-14">
                <polygon points="30,10 45,25 38,45 22,45 15,25" fill="none" stroke="#eaf5ff" strokeWidth="1.5" />
                <circle cx="30" cy="28" r="4" fill="#ffffff" filter="drop-shadow(0 0 4px #a5d8ff)" />
                <line x1="30" y1="2" x2="30" y2="10" stroke="#71717a" strokeWidth="1.5" />
              </svg>
            </div>
            <span className="text-[11px] font-semibold text-[#c5e3ff] mt-2 tracking-wider uppercase">
              The Chandelier
            </span>
          </div>

          {/* Central Shared Ember Fleck */}
          <div className="flex flex-col items-center">
            <div className="w-4 h-4 rounded-full bg-[#ffad42] shadow-[0_0_15px_#ffad42] animate-ember" />
            <span className="text-[9px] text-[#71717a] mt-2 tracking-widest uppercase">
              Intel 18A
            </span>
          </div>

          {/* Small Lantern Silhouette with warm halo */}
          <div
            className="flex flex-col items-center group cursor-pointer"
            onClick={() => {
              sound.playAmberWarmth(240);
              setActiveModalProduct('core');
            }}
          >
            <div className="w-24 h-24 rounded-full bg-[#ffad42]/10 border border-[#ffad42]/30 flex items-center justify-center shadow-[0_0_30px_rgba(255,173,66,0.3)] group-hover:scale-110 transition-transform">
              <svg viewBox="0 0 60 60" className="w-14 h-14">
                <path d="M22,20 C18,32 18,44 30,48 C42,44 42,32 38,20 Z" fill="none" stroke="#ffb45b" strokeWidth="1.5" />
                <rect x="25" y="14" width="10" height="4" fill="#d97706" />
                <circle cx="30" cy="32" r="3.5" fill="#ffffff" filter="drop-shadow(0 0 4px #ffad42)" />
              </svg>
            </div>
            <span className="text-[11px] font-semibold text-[#ffb45b] mt-2 tracking-wider uppercase">
              The Lantern
            </span>
          </div>
        </div>

        {/* Master Staggered Cinematic Headline */}
        <CinematicHeader
          className="mb-14"
          reducedMotion={reducedMotion}
          headline={
            <>
              ONE ORIGIN. TWO EXPRESSIONS<span className="text-[#ffad42]">.</span>
            </>
          }
          subtitle="Your world has its own light. Choose the one that fits."
          actions={
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 max-w-2xl mx-auto">
              <button
                onClick={() => {
                  sound.playClick();
                  onSelectUltra();
                }}
                className="w-full sm:w-auto px-6 py-3.5 text-xs font-semibold tracking-widest uppercase text-[#08090c] bg-[#c5e3ff] hover:bg-[#eaf5ff] rounded transition-all cursor-pointer shadow-[0_0_20px_rgba(197,227,255,0.4)] whitespace-nowrap"
              >
                Explore Core Ultra Series 3
              </button>

              <button
                onClick={() => {
                  sound.playClick();
                  onSelectCore();
                }}
                className="w-full sm:w-auto px-6 py-3.5 text-xs font-semibold tracking-widest uppercase text-[#08090c] bg-[#ffb45b] hover:bg-[#ffd48a] rounded transition-all cursor-pointer shadow-[0_0_20px_rgba(255,180,91,0.4)] whitespace-nowrap"
              >
                Explore Core Series 3
              </button>

              <button
                onClick={() => {
                  sound.playClick();
                  onRestart();
                }}
                className="w-full sm:w-auto px-5 py-3.5 text-xs font-semibold tracking-widest uppercase text-white bg-white/5 hover:bg-white/10 border border-white/10 rounded transition-all cursor-pointer flex items-center justify-center gap-2 whitespace-nowrap"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Choose Again</span>
              </button>
            </div>
          }
        />

        {/* Campaign Signature */}
        <div className="flex flex-col items-center gap-2 select-none">
          <div className="w-1.5 h-1.5 rounded-full bg-[#ffad42] shadow-[0_0_12px_#ffad42]" />
          <span className="text-xs font-bold tracking-[0.3em] uppercase text-white">
            BORN IN THE SAME FLAME
          </span>
          <span className="text-[11px] text-[#71717a] tracking-wider">
            An Intel Architectural Metaphor Showcase
          </span>
        </div>
      </div>

      {/* Quiet Legal & Attribution Footer */}
      <div className="relative z-10 max-w-7xl mx-auto w-full pt-12 mt-12 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-[#71717a]">
        <div>
          <span>© 2026 Creative Concept Campaign Demonstration. All processor specifications represent proposed campaign metrics.</span>
        </div>

        <button
          onClick={scrollToTop}
          className="flex items-center gap-1.5 text-[#a1a1aa] hover:text-white transition-colors cursor-pointer"
        >
          <span>Return to Origin</span>
          <ArrowUp className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Deep-Dive Product Modal */}
      {activeModalProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="relative w-full max-w-lg p-6 sm:p-8 rounded-2xl bg-[#121419] border border-white/20 shadow-2xl text-left">
            {activeModalProduct === 'ultra' ? (
              <div>
                <span className="text-xs font-bold text-[#c5e3ff] uppercase tracking-wider block mb-1">
                  Architecture Deep Dive
                </span>
                <h3 className="text-2xl font-bold text-white mb-2">{ultra.name}</h3>
                <p className="text-xs text-[#ffad42] mb-4">{ultra.tagline}</p>
                <p className="text-xs text-[#a1a1aa] leading-relaxed mb-6">
                  {ultra.longDescription}
                </p>
                <div className="space-y-2 text-xs text-white mb-6 bg-black/40 p-4 rounded-lg">
                  <div className="flex justify-between">
                    <span className="text-[#a1a1aa]">Peak Filaments (Cores):</span>
                    <span className="font-semibold">{ultra.cpu.maxCores} Cores</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#a1a1aa]">NPU Compute Spark:</span>
                    <span className="font-semibold">{ultra.npu.maxTops} TOPS</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#a1a1aa]">Xe3 Graphics Cores:</span>
                    <span className="font-semibold">{ultra.graphics.cores} Cores</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#a1a1aa]">Shared Process Node:</span>
                    <span className="font-semibold">{ultra.manufacturing}</span>
                  </div>
                </div>
              </div>
            ) : (
              <div>
                <span className="text-xs font-bold text-[#ffb45b] uppercase tracking-wider block mb-1">
                  Architecture Deep Dive
                </span>
                <h3 className="text-2xl font-bold text-white mb-2">{core.name}</h3>
                <p className="text-xs text-[#ffad42] mb-4">{core.tagline}</p>
                <p className="text-xs text-[#a1a1aa] leading-relaxed mb-6">
                  {core.longDescription}
                </p>
                <div className="space-y-2 text-xs text-white mb-6 bg-black/40 p-4 rounded-lg">
                  <div className="flex justify-between">
                    <span className="text-[#a1a1aa]">Tuned Filaments (Cores):</span>
                    <span className="font-semibold">{core.cpu.maxCores} Cores</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#a1a1aa]">NPU Utility Spark:</span>
                    <span className="font-semibold">{core.npu.maxTops} TOPS</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#a1a1aa]">Xe3 Graphics Cores:</span>
                    <span className="font-semibold">{core.graphics.cores} Cores</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#a1a1aa]">Shared Process Node:</span>
                    <span className="font-semibold">{core.manufacturing}</span>
                  </div>
                </div>
              </div>
            )}

            <button
              onClick={() => setActiveModalProduct(null)}
              className="w-full py-2.5 text-xs font-semibold uppercase tracking-wider bg-white/10 hover:bg-white/20 text-white rounded transition-colors cursor-pointer"
            >
              Close Deep Dive
            </button>
          </div>
        </div>
      )}
    </footer>
  );
};
