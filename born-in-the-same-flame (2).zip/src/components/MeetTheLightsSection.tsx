/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Cpu, Sparkles, Monitor, Layers, ShieldCheck, ArrowRight } from 'lucide-react';
import { motion } from 'motion/react';
import { CAMPAIGN_DATA } from '../data/campaignConfig';
import { sound } from '../utils/audio';
import { CinematicHeader } from './CinematicHeader';
import { cardRevealVariants } from '../utils/motionVariants';

interface MeetTheLightsSectionProps {
  onSelectProduct: (productId: 'ultra' | 'core') => void;
  onGoToComparison: () => void;
  reducedMotion?: boolean;
}

export const MeetTheLightsSection: React.FC<MeetTheLightsSectionProps> = ({
  onSelectProduct,
  onGoToComparison,
  reducedMotion = false
}) => {
  const [activeSide, setActiveSide] = useState<'ultra' | 'core' | null>(null);
  const [chandelierIntensity, setChandelierIntensity] = useState(1);
  const [lanternIntensity, setLanternIntensity] = useState(1);
  const [hoveredFilament, setHoveredFilament] = useState<number | null>(null);

  const ultra = CAMPAIGN_DATA.products.ultra;
  const core = CAMPAIGN_DATA.products.core;

  const handleChandelierClick = () => {
    sound.playCrystalChime(880);
    setActiveSide('ultra');
    setChandelierIntensity((prev) => (prev >= 1.5 ? 1 : prev + 0.25));
  };

  const handleLanternClick = () => {
    sound.playAmberWarmth(240);
    setActiveSide('core');
    setLanternIntensity((prev) => (prev >= 1.5 ? 1 : prev + 0.25));
  };

  return (
    <section
      id="lights"
      className="relative min-h-screen w-full py-28 px-6 sm:px-12 bg-[#08090c] border-t border-white/5 flex flex-col justify-center"
    >
      <div className="max-w-7xl mx-auto w-full">
        {/* Editorial Section Header */}
        <CinematicHeader
          className="mb-16 sm:mb-20"
          reducedMotion={reducedMotion}
          kicker={
            <>
              <span>Dual Expressions</span>
              <span className="text-[#a1a1aa]" aria-hidden="true">·</span>
              <span>Balanced Intentionality</span>
            </>
          }
          headline={
            <>
              MEET THE TWO LIGHTS<span className="text-[#ffad42]">.</span>
            </>
          }
          subtitle="Neither light is lesser. Each was shaped for a distinct realm of human endeavor."
        />

        {/* Side-by-Side Product Presentation */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12 items-stretch">
          {/* ========================================================= */}
          {/* LEFT: THE CRYSTAL CHANDELIER (Core Ultra Series 3) */}
          {/* ========================================================= */}
          <motion.div
            variants={cardRevealVariants}
            custom={{ reducedMotion, delay: 0.08 }}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.2 }}
            className={`group relative rounded-2xl bg-[#121419]/90 border transition-all duration-500 p-8 sm:p-10 flex flex-col justify-between overflow-hidden cursor-pointer ${
              activeSide === 'ultra'
                ? 'border-[#c5e3ff]/60 shadow-[0_0_50px_rgba(197,227,255,0.25)]'
                : 'border-white/10 hover:border-[#c5e3ff]/40 shadow-xl'
            }`}
            onClick={handleChandelierClick}
            onMouseEnter={() => {
              if (activeSide !== 'ultra') sound.playCrystalChime(660);
            }}
          >
            {/* Ambient Background Aura */}
            <div
              className="absolute -top-24 -left-24 w-96 h-96 rounded-full blur-[110px] pointer-events-none transition-all duration-700"
              style={{
                background: 'radial-gradient(circle, rgba(165,216,255,0.3) 0%, rgba(107,183,255,0.1) 50%, transparent 80%)',
                transform: `scale(${chandelierIntensity})`
              }}
            />

            <div>
              {/* Product Subtitle & Name */}
              <div className="flex items-center justify-between text-xs tracking-widest uppercase mb-3">
                <span className="text-[#a5d8ff] font-semibold">{ultra.name}</span>
                <span className="text-[#a1a1aa]">{ultra.metaphorName}</span>
              </div>

              <h3 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white mb-3 text-balance">
                {ultra.heroHeadline}
              </h3>

              <p className="text-sm text-[#a1a1aa] leading-relaxed mb-6 text-balance">
                {ultra.shortDescription}
              </p>

              {/* Visual Chandelier Representation with 16 Animated Filaments */}
              <div className="relative w-full h-64 sm:h-72 my-4 rounded-xl bg-[#08090c]/80 border border-white/5 flex items-center justify-center overflow-hidden">
                {/* Ray Scatter Effect */}
                <div
                  className="absolute inset-0 pointer-events-none transition-opacity duration-500 animate-crystal-rays"
                  style={{
                    background:
                      'radial-gradient(ellipse at 50% 45%, rgba(203,229,254,0.18) 0%, transparent 70%)',
                    opacity: chandelierIntensity > 1 ? 0.9 : 0.5
                  }}
                />

                {/* SVG Chandelier Visual */}
                <svg
                  viewBox="0 0 320 240"
                  className="w-full h-full max-h-60 overflow-visible transition-transform duration-300 group-hover:scale-105"
                >
                  <defs>
                    <radialGradient id="sparkUltra" cx="50%" cy="50%" r="50%">
                      <stop offset="0%" stopColor="#ffffff" />
                      <stop offset="40%" stopColor="#90caf9" />
                      <stop offset="100%" stopColor="#08090c" stopOpacity="0" />
                    </radialGradient>
                    <linearGradient id="crystalFacet" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor="#ffffff" stopOpacity="0.8" />
                      <stop offset="50%" stopColor="#a5d8ff" stopOpacity="0.3" />
                      <stop offset="100%" stopColor="#4dabf7" stopOpacity="0.1" />
                    </linearGradient>
                  </defs>

                  {/* Ceiling Suspension Rod & Crown */}
                  <line x1="160" y1="0" x2="160" y2="40" stroke="#71717a" strokeWidth="2" />
                  <ellipse cx="160" cy="40" rx="35" ry="8" fill="#272a34" stroke="#a5d8ff" strokeWidth="1" />

                  {/* Radiating Light Strands */}
                  <line x1="160" y1="40" x2="100" y2="100" stroke="#c5e3ff" strokeWidth="1.2" strokeDasharray="2 3" opacity="0.6" />
                  <line x1="160" y1="40" x2="220" y2="100" stroke="#c5e3ff" strokeWidth="1.2" strokeDasharray="2 3" opacity="0.6" />
                  <line x1="160" y1="40" x2="160" y2="100" stroke="#c5e3ff" strokeWidth="1.2" opacity="0.7" />

                  {/* Tier 1 Prisms (Crystal Body) */}
                  <polygon points="160,50 195,95 175,140 145,140 125,95" fill="url(#crystalFacet)" stroke="#eaf5ff" strokeWidth="1.5" />
                  <polygon points="160,65 180,95 168,130 152,130 140,95" fill="none" stroke="#a5d8ff" strokeWidth="1" opacity="0.8" />

                  {/* 16 Glowing Filaments (representing up to 16 CPU cores) */}
                  {Array.from({ length: 16 }).map((_, i) => {
                    const angle = (i / 16) * Math.PI * 2;
                    const rBase = 65;
                    const fx = 160 + Math.cos(angle) * rBase;
                    const fy = 110 + Math.sin(angle) * 35;
                    const isHovered = hoveredFilament === i;
                    return (
                      <g
                        key={i}
                        className="cursor-pointer"
                        onMouseEnter={() => setHoveredFilament(i)}
                        onMouseLeave={() => setHoveredFilament(null)}
                      >
                        <line
                          x1={160}
                          y1={105}
                          x2={fx}
                          y2={fy}
                          stroke={isHovered ? '#ffffff' : '#cbe5fe'}
                          strokeWidth={isHovered ? 2.5 : 1.5}
                          strokeLinecap="round"
                          opacity={isHovered ? 1 : 0.85}
                          className="transition-all"
                        />
                        <circle
                          cx={fx}
                          cy={fy}
                          r={isHovered ? 4.5 : 3}
                          fill={isHovered ? '#ffffff' : '#a5d8ff'}
                          filter="drop-shadow(0 0 6px #6bb7ff)"
                        />
                      </g>
                    );
                  })}

                  {/* Hanging Cut Crystal Pendants */}
                  <polygon points="160,140 166,170 160,185 154,170" fill="#eaf5ff" opacity="0.9" />
                  <polygon points="125,120 130,150 125,162 120,150" fill="#cbe5fe" opacity="0.8" />
                  <polygon points="195,120 200,150 195,162 190,150" fill="#cbe5fe" opacity="0.8" />
                  <polygon points="95,100 100,128 95,138 90,128" fill="#a5d8ff" opacity="0.7" />
                  <polygon points="225,100 230,128 225,138 220,128" fill="#a5d8ff" opacity="0.7" />

                  {/* NPU Dedicated Inner Spark (Up to 50 TOPS) */}
                  <circle
                    cx="160"
                    cy="105"
                    r={8 * chandelierIntensity}
                    fill="url(#sparkUltra)"
                    className="animate-pulse"
                  />
                  <circle cx="160" cy="105" r="4" fill="#ffffff" />
                </svg>

                <div className="absolute bottom-3 left-4 right-4 flex items-center justify-between text-[11px] text-[#a1a1aa] bg-[#08090c]/70 px-3 py-1.5 rounded backdrop-blur-sm border border-white/5">
                  <span>16 Interactive Cores</span>
                  <span className="text-[#a5d8ff]">Click to brighten crystal aura</span>
                </div>
              </div>

              {/* Revealed Capability Badges */}
              <div className="grid grid-cols-3 gap-3 my-6 pt-4 border-t border-white/5">
                <div className="p-3 rounded-lg bg-black/30 border border-white/5 text-center">
                  <div className="flex items-center justify-center gap-1 text-[#a5d8ff] mb-1">
                    <Cpu className="w-3.5 h-3.5" />
                    <span className="text-xs font-semibold uppercase">CPU</span>
                  </div>
                  <div className="text-lg font-bold text-white tabular-nums">16 Cores</div>
                  <div className="text-[10px] text-[#71717a]">Peak Multi-thread</div>
                </div>

                <div className="p-3 rounded-lg bg-black/30 border border-white/5 text-center">
                  <div className="flex items-center justify-center gap-1 text-[#a5d8ff] mb-1">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span className="text-xs font-semibold uppercase">NPU</span>
                  </div>
                  <div className="text-lg font-bold text-white tabular-nums">50 TOPS</div>
                  <div className="text-[10px] text-[#71717a]">On-Device AI</div>
                </div>

                <div className="p-3 rounded-lg bg-black/30 border border-white/5 text-center">
                  <div className="flex items-center justify-center gap-1 text-[#a5d8ff] mb-1">
                    <Monitor className="w-3.5 h-3.5" />
                    <span className="text-xs font-semibold uppercase">Xe3</span>
                  </div>
                  <div className="text-lg font-bold text-white tabular-nums">12 Cores</div>
                  <div className="text-[10px] text-[#71717a]">Expanded Canvas</div>
                </div>
              </div>

              {/* Intended Atmosphere Description */}
              <p className="text-xs text-[#a1a1aa] leading-relaxed mb-6">
                Cast for expansive environments where ideas multiply rapidly. Generates generous thermal and computing headroom for real-time 3D, raw video encoding, generative AI diffusion, and immersive worlds.
              </p>
            </div>

            {/* Action Bar */}
            <div className="pt-4 border-t border-white/5 flex items-center justify-between">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  sound.playClick();
                  onSelectProduct('ultra');
                }}
                className="text-xs font-semibold tracking-wider uppercase text-[#a5d8ff] hover:text-white flex items-center gap-1.5 cursor-pointer"
              >
                <span>View Creator Studio</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
              <span className="text-[11px] text-[#71717a]">Expansive Power</span>
            </div>
          </motion.div>

          {/* ========================================================= */}
          {/* RIGHT: THE AMBER LANTERN (Core Series 3) */}
          {/* ========================================================= */}
          <motion.div
            variants={cardRevealVariants}
            custom={{ reducedMotion, delay: 0.2 }}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.2 }}
            className={`group relative rounded-2xl bg-[#121419]/90 border transition-all duration-500 p-8 sm:p-10 flex flex-col justify-between overflow-hidden cursor-pointer ${
              activeSide === 'core'
                ? 'border-[#ffb45b]/60 shadow-[0_0_50px_rgba(255,180,91,0.25)]'
                : 'border-white/10 hover:border-[#ffb45b]/40 shadow-xl'
            }`}
            onClick={handleLanternClick}
            onMouseEnter={() => {
              if (activeSide !== 'core') sound.playAmberWarmth(220);
            }}
          >
            {/* Ambient Background Aura */}
            <div
              className="absolute -top-24 -right-24 w-96 h-96 rounded-full blur-[110px] pointer-events-none transition-all duration-700"
              style={{
                background: 'radial-gradient(circle, rgba(255,180,91,0.3) 0%, rgba(217,119,6,0.1) 50%, transparent 80%)',
                transform: `scale(${lanternIntensity})`
              }}
            />

            <div>
              {/* Product Subtitle & Name */}
              <div className="flex items-center justify-between text-xs tracking-widest uppercase mb-3">
                <span className="text-[#ffb45b] font-semibold">{core.name}</span>
                <span className="text-[#a1a1aa]">{core.metaphorName}</span>
              </div>

              <h3 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white mb-3 text-balance">
                {core.heroHeadline}
              </h3>

              <p className="text-sm text-[#a1a1aa] leading-relaxed mb-6 text-balance">
                {core.shortDescription}
              </p>

              {/* Visual Amber Lantern Representation with 6 Animated Filaments */}
              <div className="relative w-full h-64 sm:h-72 my-4 rounded-xl bg-[#08090c]/80 border border-white/5 flex items-center justify-center overflow-hidden">
                {/* Gentle Ray Scatter Effect */}
                <div
                  className="absolute inset-0 pointer-events-none transition-opacity duration-500"
                  style={{
                    background:
                      'radial-gradient(ellipse at 50% 50%, rgba(255,180,91,0.2) 0%, transparent 65%)',
                    opacity: lanternIntensity > 1 ? 0.9 : 0.55
                  }}
                />

                {/* SVG Lantern Visual */}
                <svg
                  viewBox="0 0 320 240"
                  className="w-full h-full max-h-60 overflow-visible transition-transform duration-300 group-hover:scale-105"
                >
                  <defs>
                    <radialGradient id="sparkLantern" cx="50%" cy="50%" r="50%">
                      <stop offset="0%" stopColor="#ffffff" />
                      <stop offset="50%" stopColor="#ffb45b" />
                      <stop offset="100%" stopColor="#08090c" stopOpacity="0" />
                    </radialGradient>
                    <linearGradient id="amberGlass" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor="#ffd88a" stopOpacity="0.4" />
                      <stop offset="50%" stopColor="#ff9f22" stopOpacity="0.15" />
                      <stop offset="100%" stopColor="#b45309" stopOpacity="0.25" />
                    </linearGradient>
                  </defs>

                  {/* Brass Ring & Lantern Handle */}
                  <path
                    d="M135,35 C135,10 185,10 185,35"
                    fill="none"
                    stroke="#d97706"
                    strokeWidth="3"
                    strokeLinecap="round"
                  />
                  {/* Brass Hood / Top Cap */}
                  <rect x="125" y="35" width="70" height="12" rx="4" fill="#92400e" stroke="#f59e0b" strokeWidth="1" />
                  <rect x="135" y="47" width="50" height="8" fill="#78350f" />

                  {/* Hand-Blown Amber Glass Bell Silhouette */}
                  <path
                    d="M110,60 C90,110 95,165 125,180 C150,190 170,190 195,180 C225,165 230,110 210,60 Z"
                    fill="url(#amberGlass)"
                    stroke="#ffb45b"
                    strokeWidth="2"
                    opacity="0.9"
                  />

                  {/* Glass Specular Highlight Curve */}
                  <path
                    d="M118,75 C104,115 106,155 126,170"
                    fill="none"
                    stroke="#ffffff"
                    strokeWidth="1.5"
                    opacity="0.6"
                    strokeLinecap="round"
                  />

                  {/* 6 Glowing Filaments (representing up to 6 CPU cores) */}
                  {Array.from({ length: 6 }).map((_, i) => {
                    const offset = (i - 2.5) * 14;
                    const fx = 160 + offset;
                    return (
                      <g key={i}>
                        {/* Filament loop */}
                        <path
                          d={`M${fx - 4},75 Q${fx},145 ${fx + 4},75`}
                          fill="none"
                          stroke="#ffea9f"
                          strokeWidth="2"
                          strokeLinecap="round"
                          className="animate-filament"
                          style={{ animationDelay: `${i * 0.2}s` }}
                          filter="drop-shadow(0 0 5px #ffad42)"
                        />
                      </g>
                    );
                  })}

                  {/* Lantern Base */}
                  <rect x="120" y="180" width="80" height="12" rx="3" fill="#92400e" stroke="#f59e0b" strokeWidth="1" />

                  {/* NPU Visible Inner Spark (Up to 17 TOPS) */}
                  <circle
                    cx="160"
                    cy="115"
                    r={6 * lanternIntensity}
                    fill="url(#sparkLantern)"
                    className="animate-pulse"
                  />
                  <circle cx="160" cy="115" r="3" fill="#ffffff" />
                </svg>

                <div className="absolute bottom-3 left-4 right-4 flex items-center justify-between text-[11px] text-[#a1a1aa] bg-[#08090c]/70 px-3 py-1.5 rounded backdrop-blur-sm border border-white/5">
                  <span>6 Focused Cores</span>
                  <span className="text-[#ffb45b]">Click to warm lantern pool</span>
                </div>
              </div>

              {/* Revealed Capability Badges */}
              <div className="grid grid-cols-3 gap-3 my-6 pt-4 border-t border-white/5">
                <div className="p-3 rounded-lg bg-black/30 border border-white/5 text-center">
                  <div className="flex items-center justify-center gap-1 text-[#ffb45b] mb-1">
                    <Cpu className="w-3.5 h-3.5" />
                    <span className="text-xs font-semibold uppercase">CPU</span>
                  </div>
                  <div className="text-lg font-bold text-white tabular-nums">6 Cores</div>
                  <div className="text-[10px] text-[#71717a]">Agile Efficiency</div>
                </div>

                <div className="p-3 rounded-lg bg-black/30 border border-white/5 text-center">
                  <div className="flex items-center justify-center gap-1 text-[#ffb45b] mb-1">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span className="text-xs font-semibold uppercase">NPU</span>
                  </div>
                  <div className="text-lg font-bold text-white tabular-nums">17 TOPS</div>
                  <div className="text-[10px] text-[#71717a]">Smart Utility</div>
                </div>

                <div className="p-3 rounded-lg bg-black/30 border border-white/5 text-center">
                  <div className="flex items-center justify-center gap-1 text-[#ffb45b] mb-1">
                    <Monitor className="w-3.5 h-3.5" />
                    <span className="text-xs font-semibold uppercase">Xe3</span>
                  </div>
                  <div className="text-lg font-bold text-white tabular-nums">2 Cores</div>
                  <div className="text-[10px] text-[#71717a]">Focused Desk</div>
                </div>
              </div>

              {/* Intended Atmosphere Description */}
              <p className="text-xs text-[#a1a1aa] leading-relaxed mb-6">
                Shaped for intentional focus where efficiency and calmness reign. Casts a warm, dedicated circle of light over your notebook, research documents, and daily calls without excess heat or unnecessary drain.
              </p>
            </div>

            {/* Action Bar */}
            <div className="pt-4 border-t border-white/5 flex items-center justify-between">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  sound.playClick();
                  onSelectProduct('core');
                }}
                className="text-xs font-semibold tracking-wider uppercase text-[#ffb45b] hover:text-white flex items-center gap-1.5 cursor-pointer"
              >
                <span>View Study Desk</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
              <span className="text-[11px] text-[#71717a]">Focused Warmth</span>
            </div>
          </motion.div>
        </div>

        {/* Bottom CTA to Comparison */}
        <div className="mt-14 text-center">
          <button
            onClick={() => {
              sound.playClick();
              onGoToComparison();
            }}
            className="px-8 py-3.5 text-xs font-semibold tracking-widest uppercase text-white bg-white/10 hover:bg-white/15 border border-white/20 rounded transition-all cursor-pointer inline-flex items-center gap-2"
          >
            <span>Compare Filaments, TOPS & Footprints</span>
            <ArrowRight className="w-4 h-4 text-[#ffad42]" />
          </button>
        </div>
      </div>
    </section>
  );
};
