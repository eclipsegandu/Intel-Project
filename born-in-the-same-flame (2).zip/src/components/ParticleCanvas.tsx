/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef } from 'react';

interface Particle {
  x: number;
  y: number;
  size: number;
  speedX: number;
  speedY: number;
  opacity: number;
  hue: number;
  life: number;
  maxLife: number;
}

export const ParticleCanvas: React.FC<{ reducedMotion?: boolean; intensity?: number }> = ({
  reducedMotion = false,
  intensity = 1.0
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };

    window.addEventListener('resize', handleResize);

    if (reducedMotion) {
      // Draw static ambient subtle glow
      ctx.fillStyle = '#08090c';
      ctx.fillRect(0, 0, width, height);
      return () => window.removeEventListener('resize', handleResize);
    }

    const particleCount = Math.min(Math.floor((width * height) / 28000 * intensity), 75);
    const particles: Particle[] = [];

    const createParticle = (initialY?: number): Particle => {
      const maxLife = 180 + Math.random() * 200;
      return {
        x: Math.random() * width,
        y: initialY !== undefined ? initialY : Math.random() * height,
        size: 1 + Math.random() * 2.2,
        speedX: (Math.random() - 0.5) * 0.45,
        speedY: -(0.25 + Math.random() * 0.75), // float upwards like hot furnace air
        opacity: 0.15 + Math.random() * 0.5,
        hue: 32 + Math.random() * 18, // golden amber to orange-red
        life: 0,
        maxLife
      };
    };

    for (let i = 0; i < particleCount; i++) {
      particles.push(createParticle());
    }

    const render = () => {
      ctx.clearRect(0, 0, width, height);

      for (let i = 0; i < particles.length; i++) {
        const p = particles[i];
        p.life++;
        p.x += p.speedX;
        p.y += p.speedY;

        // Subtle gentle drift
        p.speedX += (Math.random() - 0.5) * 0.02;

        const progress = p.life / p.maxLife;
        let alpha = p.opacity;
        if (progress < 0.2) {
          alpha = p.opacity * (progress / 0.2);
        } else if (progress > 0.7) {
          alpha = p.opacity * (1 - (progress - 0.7) / 0.3);
        }

        ctx.save();
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fillStyle = `hsla(${p.hue}, 95%, 62%, ${Math.max(0, alpha)})`;
        ctx.shadowBlur = p.size * 5;
        ctx.shadowColor = `hsla(${p.hue}, 100%, 50%, ${alpha})`;
        ctx.fill();
        ctx.restore();

        // Recycle particle
        if (p.life >= p.maxLife || p.y < -10 || p.x < -10 || p.x > width + 10) {
          particles[i] = createParticle(height + 10);
        }
      }

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animationFrameId);
    };
  }, [reducedMotion, intensity]);

  return (
    <canvas
      ref={canvasRef}
      className="pointer-events-none fixed inset-0 z-0 h-full w-full opacity-60"
      aria-hidden="true"
    />
  );
};
