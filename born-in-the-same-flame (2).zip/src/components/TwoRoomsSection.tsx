/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Film,
  Box,
  Gamepad2,
  Palette,
  BookOpen,
  Video,
  FileText,
  Calendar,
  Coffee,
  Play,
  Pause,
  Maximize2
} from 'lucide-react';
import { sound } from '../utils/audio';
import { CinematicHeader } from './CinematicHeader';
import { motion } from 'motion/react';
import { scaleFadeVariants } from '../utils/motionVariants';

interface TwoRoomsSectionProps {
  reducedMotion?: boolean;
}

export const TwoRoomsSection: React.FC<TwoRoomsSectionProps> = ({ reducedMotion = false }) => {
  const [activeRoom, setActiveRoom] = useState<'studio' | 'desk'>('studio');
  const [isPlayingTimeline, setIsPlayingTimeline] = useState(false);
  const [timelinePlayhead, setTimelinePlayhead] = useState(38);
  const [isVideoMuted, setIsVideoMuted] = useState(true);

  const handleRoomSelect = (room: 'studio' | 'desk') => {
    sound.playClick();
    if (room === 'studio') {
      sound.playCrystalChime(780);
    } else {
      sound.playAmberWarmth(220);
    }
    setActiveRoom(room);
  };

  return (
    <section
      id="rooms"
      className="relative min-h-screen w-full py-28 px-6 sm:px-12 bg-[#08090c] border-t border-white/5 flex flex-col justify-center"
    >
      <div className="max-w-7xl mx-auto w-full">
        {/* Section Header */}
        <CinematicHeader
          className="mb-10 sm:mb-14"
          reducedMotion={reducedMotion}
          kicker={
            <>
              <span>Environments & Ambience</span>
              <span className="text-[#a1a1aa]" aria-hidden="true">·</span>
              <span>Realms of Application</span>
            </>
          }
          headline={
            <>
              TWO ROOMS. TWO DIFFERENT WORLDS<span className="text-[#ffad42]">.</span>
            </>
          }
          subtitle="Light does not exist in isolation. It takes shape through the architecture of the rooms it illuminates."
          actions={
            <div className="inline-flex items-center p-1.5 rounded-xl bg-[#121419] border border-white/10 shadow-lg">
              <button
                onClick={() => handleRoomSelect('studio')}
                className={`px-6 py-2.5 text-xs font-semibold tracking-wider uppercase rounded-lg transition-all cursor-pointer flex items-center gap-2 ${
                  activeRoom === 'studio'
                    ? 'bg-[#c5e3ff] text-[#08090c] shadow-[0_0_25px_rgba(197,227,255,0.4)]'
                    : 'text-[#a1a1aa] hover:text-white'
                }`}
              >
                <span>The Creator's Studio</span>
                <span className="text-[10px] opacity-75 font-normal">(Chandelier)</span>
              </button>
              <button
                onClick={() => handleRoomSelect('desk')}
                className={`px-6 py-2.5 text-xs font-semibold tracking-wider uppercase rounded-lg transition-all cursor-pointer flex items-center gap-2 ${
                  activeRoom === 'desk'
                    ? 'bg-[#ffb45b] text-[#08090c] shadow-[0_0_25px_rgba(255,180,91,0.4)]'
                    : 'text-[#a1a1aa] hover:text-white'
                }`}
              >
                <span>The Study Desk</span>
                <span className="text-[10px] opacity-75 font-normal">(Lantern)</span>
              </button>
            </div>
          }
        />

        {/* ================================================================= */}
        {/* ROOM A: THE CREATOR'S STUDIO (Illuminated by the Crystal Chandelier) */}
        {/* ================================================================= */}
        {activeRoom === 'studio' && (
          <motion.div
            variants={scaleFadeVariants}
            custom={{ reducedMotion }}
            initial="hidden"
            animate="visible"
            className="relative rounded-2xl bg-[#121419]/90 border border-[#c5e3ff]/30 p-6 sm:p-10 shadow-2xl overflow-hidden backdrop-blur-md transition-all duration-500"
          >
            {/* Ambient Chandelier Refraction Rays in Room */}
            <div
              className="absolute -top-32 left-1/2 -translate-x-1/2 w-[700px] h-[500px] pointer-events-none rounded-full blur-[120px]"
              style={{
                background:
                  'radial-gradient(circle, rgba(203,229,254,0.2) 0%, rgba(107,183,255,0.08) 50%, transparent 80%)'
              }}
            />

            <div className="relative z-10">
              {/* Room Title & Story Header */}
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8 pb-6 border-b border-white/10">
                <div>
                  <span className="text-xs font-bold uppercase tracking-widest text-[#a5d8ff] block mb-1">
                    Powered by Intel® Core™ Ultra Series 3
                  </span>
                  <h3 className="text-2xl sm:text-3xl font-extrabold text-white text-balance">
                    WHEN YOUR IDEAS NEED THE WHOLE ROOM.
                  </h3>
                </div>
                <p className="text-xs sm:text-sm text-[#a1a1aa] max-w-md">
                  Explore a world of creative possibilities with Intel Core Ultra Series 3. Designed for multi-canvas fluidity, rendering velocity, and boundless headroom.
                </p>
              </div>

              {/* Interactive Multi-Window Workspace Grid */}
              <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
                {/* 1. Video Editing Timeline (Span 8) */}
                <div className="md:col-span-8 p-5 rounded-xl bg-[#08090c]/90 border border-white/10 flex flex-col justify-between">
                  <div className="flex items-center justify-between mb-3 text-xs">
                    <div className="flex items-center gap-2 text-white font-medium">
                      <Film className="w-4 h-4 text-[#a5d8ff]" />
                      <span>Cinema Sequence · 4K 10-bit Timeline</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => {
                          sound.playClick();
                          setIsPlayingTimeline(!isPlayingTimeline);
                        }}
                        className="px-2.5 py-1 rounded bg-white/10 hover:bg-white/20 text-white text-[11px] flex items-center gap-1 cursor-pointer"
                      >
                        {isPlayingTimeline ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3" />}
                        <span>{isPlayingTimeline ? 'Pause' : 'Play'}</span>
                      </button>
                      <span className="text-[#a1a1aa] tabular-nums font-mono text-[11px]">
                        00:04:12:18
                      </span>
                    </div>
                  </div>

                  {/* Multi-track timeline tracks */}
                  <div className="space-y-2 my-2 bg-black/60 p-3 rounded-lg border border-white/5">
                    {/* Track V1 */}
                    <div className="relative h-7 rounded bg-[#1e293b] flex items-center px-2 text-[10px] text-white overflow-hidden">
                      <span className="z-10 font-mono">V1: Anamorphic_A-Roll.mov (ProRes RAW)</span>
                      <div className="absolute inset-y-0 left-0 bg-[#2563eb]/40 w-3/4 border-r border-[#60a5fa]" />
                    </div>

                    {/* Track V2 */}
                    <div className="relative h-7 rounded bg-[#1e293b] flex items-center px-2 text-[10px] text-white overflow-hidden">
                      <span className="z-10 font-mono">V2: VFX_Chandelier_Refractions.exr (32-bit float)</span>
                      <div className="absolute inset-y-0 left-1/4 bg-[#8b5cf6]/40 w-1/2 border-r border-[#c084fc]" />
                    </div>

                    {/* Track A1 & A2 Audio */}
                    <div className="relative h-7 rounded bg-[#0f172a] flex items-center px-2 text-[10px] text-[#94a3b8] overflow-hidden">
                      <span className="z-10 font-mono">A1-A2: Atmos_Orchestral_Score_96kHz.wav</span>
                      {/* Audio waveform illustration */}
                      <div className="absolute inset-0 flex items-center justify-around opacity-40 px-4">
                        {Array.from({ length: 36 }).map((_, i) => (
                          <div
                            key={i}
                            className="w-1 bg-[#38bdf8] rounded-full"
                            style={{ height: `${20 + Math.sin(i * 0.7) * 70}%` }}
                          />
                        ))}
                      </div>
                    </div>

                    {/* Playhead Scrubber */}
                    <div className="relative h-3 w-full bg-white/5 rounded">
                      <div
                        className="absolute top-0 bottom-0 w-1 bg-[#ffad42] shadow-[0_0_8px_#ffad42]"
                        style={{ left: `${timelinePlayhead}%` }}
                      />
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-[11px] text-[#71717a] mt-2">
                    <span>16 CPU Cores: Zero Frame Drops</span>
                    <span>NPU Rotoscoping Engine Active</span>
                  </div>
                </div>

                {/* 2. 3D Viewport & Rendering (Span 4) */}
                <div className="md:col-span-4 p-5 rounded-xl bg-[#08090c]/90 border border-white/10 flex flex-col justify-between">
                  <div className="flex items-center justify-between mb-3 text-xs">
                    <div className="flex items-center gap-2 text-white font-medium">
                      <Box className="w-4 h-4 text-[#a5d8ff]" />
                      <span>3D Crystal Shader Viewport</span>
                    </div>
                    <span className="text-[10px] text-[#34d399] font-mono">Interactive RT</span>
                  </div>

                  {/* Wireframe / 3D Canvas Mockup */}
                  <div className="relative h-44 rounded-lg bg-black/80 border border-white/5 flex items-center justify-center overflow-hidden">
                    <svg viewBox="0 0 160 140" className="w-36 h-36">
                      <polygon
                        points="80,15 140,55 80,95 20,55"
                        fill="none"
                        stroke="#a5d8ff"
                        strokeWidth="1.5"
                        strokeDasharray="2 2"
                      />
                      <polygon
                        points="80,95 140,55 140,115 80,135"
                        fill="rgba(165,216,255,0.15)"
                        stroke="#eaf5ff"
                        strokeWidth="1.5"
                      />
                      <polygon
                        points="80,95 20,55 20,115 80,135"
                        fill="rgba(107,183,255,0.2)"
                        stroke="#cbe5fe"
                        strokeWidth="1.5"
                      />
                      <circle cx="80" cy="75" r="8" fill="#ffffff" filter="drop-shadow(0 0 8px #6bb7ff)" />
                    </svg>
                    <div className="absolute bottom-2 left-2 text-[10px] text-[#71717a] font-mono">
                      Subsurface Scattering: 100%
                    </div>
                  </div>

                  <div className="text-[11px] text-[#a1a1aa] mt-2">
                    Xe3 Graphics acceleration dynamically computes complex caustics and specular bounce reflections.
                  </div>
                </div>

                {/* 3. Digital Artwork & Neural Canvas (Span 6) */}
                <div className="md:col-span-6 p-5 rounded-xl bg-[#08090c]/90 border border-white/10">
                  <div className="flex items-center justify-between mb-3 text-xs">
                    <div className="flex items-center gap-2 text-white font-medium">
                      <Palette className="w-4 h-4 text-[#a5d8ff]" />
                      <span>Neural Painting & Color Grading</span>
                    </div>
                    <span className="text-[10px] text-[#c5e3ff]">50 TOPS NPU Assisted</span>
                  </div>
                  <p className="text-xs text-[#a1a1aa] mb-3">
                    Infinite canvas with real-time AI inpainting, depth estimation, and 16-bit float color matrix grading.
                  </p>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] px-2 py-1 rounded bg-white/5 border border-white/10 text-white">
                      HDR10 Master
                    </span>
                    <span className="text-[10px] px-2 py-1 rounded bg-white/5 border border-white/10 text-white">
                      Wide P3 Gamut
                    </span>
                    <span className="text-[10px] px-2 py-1 rounded bg-white/5 border border-white/10 text-white">
                      Zero Scratch Disk Lag
                    </span>
                  </div>
                </div>

                {/* 4. High-Refresh Gaming & Simulation (Span 6) */}
                <div className="md:col-span-6 p-5 rounded-xl bg-[#08090c]/90 border border-white/10">
                  <div className="flex items-center justify-between mb-3 text-xs">
                    <div className="flex items-center gap-2 text-white font-medium">
                      <Gamepad2 className="w-4 h-4 text-[#a5d8ff]" />
                      <span>High-FPS Simulation & Gaming</span>
                    </div>
                    <span className="text-[10px] text-[#34d399] font-mono">165 Hz Ultra</span>
                  </div>
                  <p className="text-xs text-[#a1a1aa] mb-3">
                    Seamless low-latency execution with Wi-Fi 7 Multi-Link Operation, ensuring no dropped packet during competitive matches.
                  </p>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] px-2 py-1 rounded bg-white/5 border border-white/10 text-white">
                      XeSS Super Sampling
                    </span>
                    <span className="text-[10px] px-2 py-1 rounded bg-white/5 border border-white/10 text-white">
                      Thunderbolt 4 eGPU Ready
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {/* ================================================================= */}
        {/* ROOM B: THE STUDY DESK (Illuminated by the Amber Lantern) */}
        {/* ================================================================= */}
        {activeRoom === 'desk' && (
          <motion.div
            variants={scaleFadeVariants}
            custom={{ reducedMotion }}
            initial="hidden"
            animate="visible"
            className="relative rounded-2xl bg-[#121419]/90 border border-[#ffb45b]/30 p-6 sm:p-10 shadow-2xl overflow-hidden backdrop-blur-md transition-all duration-500"
          >
            {/* Ambient Warm Golden Desk Light Pool */}
            <div
              className="absolute -top-32 left-1/2 -translate-x-1/2 w-[700px] h-[500px] pointer-events-none rounded-full blur-[120px]"
              style={{
                background:
                  'radial-gradient(circle, rgba(255,180,91,0.22) 0%, rgba(217,119,6,0.08) 50%, transparent 80%)'
              }}
            />

            <div className="relative z-10">
              {/* Room Title & Story Header */}
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8 pb-6 border-b border-white/10">
                <div>
                  <span className="text-xs font-bold uppercase tracking-widest text-[#ffb45b] block mb-1">
                    Powered by Intel® Core™ Series 3
                  </span>
                  <h3 className="text-2xl sm:text-3xl font-extrabold text-white text-balance">
                    WHEN THE RIGHT LIGHT IS ALL YOU NEED.
                  </h3>
                </div>
                <p className="text-xs sm:text-sm text-[#a1a1aa] max-w-md">
                  Make space for everyday productivity with Intel Core Series 3. Designed for serene focus, whisper-quiet execution, and cool all-day reliability.
                </p>
              </div>

              {/* Interactive Focused Desk Workspace Grid */}
              <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
                {/* 1. Clear Document Editor & Research Notes (Span 7) */}
                <div className="md:col-span-7 p-5 rounded-xl bg-[#08090c]/90 border border-white/10 flex flex-col justify-between">
                  <div className="flex items-center justify-between mb-3 text-xs">
                    <div className="flex items-center gap-2 text-white font-medium">
                      <FileText className="w-4 h-4 text-[#ffb45b]" />
                      <span>Distraction-Free Thesis & Strategic Document</span>
                    </div>
                    <span className="text-[10px] text-[#ffb45b] font-mono">Autosaved to Cloud</span>
                  </div>

                  {/* Clean Editor Paper Surface */}
                  <div className="bg-[#181a20] p-4 rounded-lg border border-white/5 space-y-3 font-sans">
                    <div className="text-sm font-semibold text-white">
                      The Architecture of Quiet Momentum: Designing for Continuous Flow
                    </div>
                    <p className="text-xs text-[#a1a1aa] leading-relaxed">
                      "Real productivity is not measured in noisy fan decibels or surplus heat. It emerges when technology recedes into the background, allowing human thought to remain uninterrupted."
                    </p>
                    <div className="flex items-center gap-2 text-[11px] text-[#ffb45b]/80 pt-2 border-t border-white/5">
                      <BookOpen className="w-3.5 h-3.5" />
                      <span>14 Research References open in background · 0 thermal throttling</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-[11px] text-[#71717a] mt-3">
                    <span>Instant Wake from Sleep</span>
                    <span>All-Day Battery Reserve</span>
                  </div>
                </div>

                {/* 2. Seamless Video Conference Laptop (Span 5) */}
                <div className="md:col-span-5 p-5 rounded-xl bg-[#08090c]/90 border border-white/10 flex flex-col justify-between">
                  <div className="flex items-center justify-between mb-3 text-xs">
                    <div className="flex items-center gap-2 text-white font-medium">
                      <Video className="w-4 h-4 text-[#ffb45b]" />
                      <span>Executive Research Seminar</span>
                    </div>
                    <span className="text-[10px] text-[#34d399] font-mono">NPU AI Camera Active</span>
                  </div>

                  {/* Video Call Simulation Box */}
                  <div className="relative h-44 rounded-lg bg-black/80 border border-white/5 flex items-center justify-center overflow-hidden">
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent z-10" />
                    {/* Simulated avatar */}
                    <div className="w-20 h-20 rounded-full bg-[#272a34] border-2 border-[#ffb45b]/60 flex items-center justify-center text-white text-xl font-bold">
                      MK
                    </div>
                    <div className="absolute bottom-3 left-3 right-3 z-20 flex items-center justify-between text-[11px] text-white">
                      <div className="flex items-center gap-1.5">
                        <span className="w-2 h-2 rounded-full bg-emerald-400" />
                        <span>Prof. M. K. (Speaking)</span>
                      </div>
                      <span className="text-[#a1a1aa] text-[10px]">17 TOPS Auto-Framing</span>
                    </div>
                  </div>

                  <div className="text-[11px] text-[#a1a1aa] mt-2">
                    Intel Core Series 3 handles neural audio noise cancellation without touching battery-draining CPU cores.
                  </div>
                </div>

                {/* 3. Daily Calendar & Schedule Flow (Span 6) */}
                <div className="md:col-span-6 p-5 rounded-xl bg-[#08090c]/90 border border-white/10">
                  <div className="flex items-center justify-between mb-3 text-xs">
                    <div className="flex items-center gap-2 text-white font-medium">
                      <Calendar className="w-4 h-4 text-[#ffb45b]" />
                      <span>Daily Schedule & Flow</span>
                    </div>
                    <span className="text-[10px] text-[#a1a1aa]">Today · October 2026</span>
                  </div>
                  <div className="space-y-2 text-xs">
                    <div className="flex items-center justify-between p-2 rounded bg-white/5 text-[#f4f4f5]">
                      <span>09:00 AM · Literature Synthesis & Analysis</span>
                      <span className="text-[#a1a1aa] text-[10px]">90 min</span>
                    </div>
                    <div className="flex items-center justify-between p-2 rounded bg-white/5 text-[#f4f4f5]">
                      <span>11:30 AM · Global Team Video Discussion</span>
                      <span className="text-[#a1a1aa] text-[10px]">45 min</span>
                    </div>
                  </div>
                </div>

                {/* 4. Study Desk Atmosphere & Coffee (Span 6) */}
                <div className="md:col-span-6 p-5 rounded-xl bg-[#08090c]/90 border border-white/10 flex items-center justify-between">
                  <div>
                    <div className="flex items-center gap-2 text-white font-medium text-xs mb-1">
                      <Coffee className="w-4 h-4 text-[#ffb45b]" />
                      <span>Serene Desktop Ergonomics</span>
                    </div>
                    <p className="text-xs text-[#a1a1aa] leading-relaxed">
                      Silent fan profile, sub-watt display idle states, and whisper-quiet keyboard acoustics for pure study tranquility.
                    </p>
                  </div>
                  <div className="w-14 h-14 rounded-full bg-[#ffb45b]/10 border border-[#ffb45b]/30 flex items-center justify-center shrink-0 ml-4">
                    <Coffee className="w-6 h-6 text-[#ffb45b]" />
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </div>
    </section>
  );
};
