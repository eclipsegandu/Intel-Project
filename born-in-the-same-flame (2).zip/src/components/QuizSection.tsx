/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { ArrowLeft, ArrowRight, RotateCcw, Sparkles, Check, Info } from 'lucide-react';
import { QUIZ_QUESTIONS, CAMPAIGN_DATA } from '../data/campaignConfig';
import { sound } from '../utils/audio';
import { CinematicHeader } from './CinematicHeader';

interface QuizSectionProps {
  onExploreProduct: (productId: 'ultra' | 'core') => void;
  reducedMotion?: boolean;
}

export const QuizSection: React.FC<QuizSectionProps> = ({
  onExploreProduct,
  reducedMotion = false
}) => {
  const [currentStep, setCurrentStep] = useState<number>(0);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, string>>({});
  const [isCompleted, setIsCompleted] = useState<boolean>(false);

  const currentQuestion = QUIZ_QUESTIONS[currentStep];

  const handleSelectOption = (optionId: string) => {
    sound.playClick();
    setSelectedAnswers((prev) => ({
      ...prev,
      [currentQuestion.id]: optionId
    }));
  };

  const handleNext = () => {
    sound.playClick();
    if (currentStep < QUIZ_QUESTIONS.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      // Calculate result
      setIsCompleted(true);
      const outcome = calculateOutcome();
      if (outcome.recommendation === 'ultra') {
        sound.playCrystalChime(880);
      } else {
        sound.playAmberWarmth(240);
      }
    }
  };

  const handleBack = () => {
    sound.playClick();
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleReset = () => {
    sound.playClick();
    setSelectedAnswers({});
    setCurrentStep(0);
    setIsCompleted(false);
  };

  const calculateOutcome = () => {
    let ultraPoints = 0;
    let corePoints = 0;

    QUIZ_QUESTIONS.forEach((q) => {
      const selectedId = selectedAnswers[q.id];
      const opt = q.options.find((o) => o.id === selectedId);
      if (opt) {
        ultraPoints += opt.points.ultra;
        corePoints += opt.points.core;
      }
    });

    const total = ultraPoints + corePoints;
    const diff = Math.abs(ultraPoints - corePoints);

    if (diff <= 1 || (ultraPoints >= 4 && corePoints >= 4)) {
      return {
        recommendation: 'balanced' as const,
        title: 'A Harmonious Balance',
        metaphor: 'The Interwoven Studio & Study',
        processor: 'Depends on specific workload weight',
        explanation:
          'Your answers indicate a multifaceted day: you value agile everyday efficiency for focus sessions, yet also demand creative bursts when visual and computational headroom is needed. Explore both lights below to see which system configuration aligns with your key creative software.',
        primaryProduct: 'ultra' as const,
        secondaryProduct: 'core' as const
      };
    } else if (ultraPoints > corePoints) {
      return {
        recommendation: 'ultra' as const,
        title: 'The Crystal Chandelier',
        metaphor: 'Expansive Illuminator',
        processor: CAMPAIGN_DATA.products.ultra.name,
        explanation:
          'Your creative ambitions and graphics-intensive workflows call for room to breathe. Up to 16 CPU cores, 50 TOPS NPU, and 12 Xe3 graphics cores provide the wide-open headroom required for high-resolution video timelines, 3D rendering, and local AI model generation.',
        primaryProduct: 'ultra' as const,
        secondaryProduct: 'core' as const
      };
    } else {
      return {
        recommendation: 'core' as const,
        title: 'The Amber Lantern',
        metaphor: 'Focused Companion',
        processor: CAMPAIGN_DATA.products.core.name,
        explanation:
          'Your routine flourishes in a calm, intentional atmosphere. Up to 6 CPU cores and 17 TOPS NPU deliver fast responsiveness, whisper-quiet thermal acoustics, and all-day battery peace for rigorous research, video conferences, and seamless document multitasking.',
        primaryProduct: 'core' as const,
        secondaryProduct: 'ultra' as const
      };
    }
  };

  const outcome = calculateOutcome();

  return (
    <section
      id="quiz"
      className="relative min-h-screen w-full py-28 px-6 sm:px-12 bg-[#08090c] border-t border-white/5 flex flex-col justify-center"
    >
      <div className="max-w-4xl mx-auto w-full">
        {/* Section Header */}
        <CinematicHeader
          className="mb-12"
          reducedMotion={reducedMotion}
          kicker={
            <>
              <span>Interactive Assessment</span>
              <span className="text-[#a1a1aa]" aria-hidden="true">·</span>
              <span>Personalized Direction</span>
            </>
          }
          headline={
            <>
              WHICH ROOM FEELS LIKE YOURS<span className="text-[#ffad42]">?</span>
            </>
          }
          subtitle="Take a brief moment to reflect on your daily digital rhythm. Discover which light best illuminates your path."
        />

        {/* =============================================================== */}
        {/* QUESTION CARD */}
        {/* =============================================================== */}
        {!isCompleted ? (
          <div className="rounded-2xl bg-[#121419]/90 border border-white/10 p-6 sm:p-10 shadow-2xl backdrop-blur-sm">
            {/* Step Progress Bar */}
            <div className="mb-8">
              <div className="flex items-center justify-between text-xs text-[#a1a1aa] mb-2 font-medium">
                <span className="uppercase tracking-wider">
                  Question {currentStep + 1} of {QUIZ_QUESTIONS.length}
                </span>
                <span className="tabular-nums">
                  {Math.round(((currentStep + 1) / QUIZ_QUESTIONS.length) * 100)}% Complete
                </span>
              </div>
              <div className="w-full h-1.5 bg-[#272a34] rounded-full overflow-hidden">
                <div
                  className="h-full bg-[#ffad42] transition-all duration-300"
                  style={{ width: `${((currentStep + 1) / QUIZ_QUESTIONS.length) * 100}%` }}
                />
              </div>
            </div>

            {/* Question Text */}
            <div className="mb-8">
              <h3 className="text-xl sm:text-2xl font-bold text-white mb-2 text-balance">
                {currentQuestion.question}
              </h3>
              <p className="text-xs sm:text-sm text-[#a1a1aa]">{currentQuestion.subtitle}</p>
            </div>

            {/* Options List */}
            <div className="space-y-3 mb-10">
              {currentQuestion.options.map((option) => {
                const isSelected = selectedAnswers[currentQuestion.id] === option.id;
                return (
                  <button
                    key={option.id}
                    onClick={() => handleSelectOption(option.id)}
                    className={`w-full p-4 sm:p-5 rounded-xl border text-left transition-all cursor-pointer flex items-start justify-between gap-4 ${
                      isSelected
                        ? 'border-[#ffad42] bg-[#ffad42]/10 shadow-[0_0_20px_rgba(255,173,66,0.2)]'
                        : 'border-white/10 bg-white/[0.02] hover:border-white/20 hover:bg-white/[0.05]'
                    }`}
                  >
                    <div>
                      <div className="text-sm font-semibold text-white mb-1">
                        {option.label}
                      </div>
                      <p className="text-xs text-[#a1a1aa] leading-relaxed">
                        {option.description}
                      </p>
                    </div>

                    <div
                      className={`w-5 h-5 rounded-full border flex items-center justify-center shrink-0 mt-0.5 ${
                        isSelected
                          ? 'border-[#ffad42] bg-[#ffad42] text-[#08090c]'
                          : 'border-white/20'
                      }`}
                    >
                      {isSelected && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Bottom Navigation Controls */}
            <div className="flex items-center justify-between pt-6 border-t border-white/10">
              <button
                onClick={handleBack}
                disabled={currentStep === 0}
                className={`px-4 py-2 text-xs font-semibold uppercase tracking-wider rounded transition-colors flex items-center gap-2 cursor-pointer ${
                  currentStep === 0
                    ? 'opacity-30 cursor-not-allowed text-[#71717a]'
                    : 'text-[#a1a1aa] hover:text-white'
                }`}
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Back</span>
              </button>

              <button
                onClick={handleNext}
                disabled={!selectedAnswers[currentQuestion.id]}
                className={`px-6 py-2.5 text-xs font-semibold uppercase tracking-wider rounded transition-all flex items-center gap-2 cursor-pointer ${
                  selectedAnswers[currentQuestion.id]
                    ? 'bg-[#ffad42] hover:bg-[#ffbe5b] text-[#08090c] shadow-[0_0_20px_rgba(255,173,66,0.3)]'
                    : 'bg-white/10 text-[#71717a] cursor-not-allowed'
                }`}
              >
                <span>{currentStep === QUIZ_QUESTIONS.length - 1 ? 'Reveal Recommendation' : 'Next'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        ) : (
          /* =============================================================== */
          /* RESULTS CARD */
          /* =============================================================== */
          <div className="rounded-2xl bg-[#121419]/95 border border-white/10 p-8 sm:p-12 shadow-2xl backdrop-blur-md text-center">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-xs font-medium text-[#ffad42] mb-6">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Personalized Campaign Recommendation</span>
            </div>

            {/* Metaphor Icon & Title */}
            <div className="mb-4">
              <span className="text-xs uppercase tracking-widest text-[#a1a1aa] block mb-2">
                Your Recommended Light
              </span>
              <h3 className="text-3xl sm:text-4xl font-extrabold text-white mb-2">
                {outcome.title}
              </h3>
              <p className="text-sm font-semibold text-[#ffad42]">{outcome.processor}</p>
            </div>

            {/* Personalized Explanation */}
            <p className="text-sm text-[#a1a1aa] max-w-xl mx-auto leading-relaxed my-6 text-balance">
              {outcome.explanation}
            </p>

            {/* Working Action Buttons */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mt-8">
              <button
                onClick={() => {
                  sound.playClick();
                  onExploreProduct(outcome.primaryProduct);
                }}
                className="w-full sm:w-auto px-6 py-3 text-xs font-semibold tracking-wider uppercase bg-[#ffad42] hover:bg-[#ffbe5b] text-[#08090c] rounded transition-all cursor-pointer shadow-[0_0_20px_rgba(255,173,66,0.4)]"
              >
                Explore {outcome.title}
              </button>

              <button
                onClick={() => {
                  sound.playClick();
                  onExploreProduct(outcome.secondaryProduct);
                }}
                className="w-full sm:w-auto px-6 py-3 text-xs font-semibold tracking-wider uppercase bg-white/10 hover:bg-white/15 text-white border border-white/20 rounded transition-all cursor-pointer"
              >
                Revisit The Other Light
              </button>

              <button
                onClick={handleReset}
                className="w-full sm:w-auto px-4 py-3 text-xs font-medium text-[#a1a1aa] hover:text-white flex items-center justify-center gap-2 cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Start Again</span>
              </button>
            </div>

            {/* Disclaimer on Quiz */}
            <div className="mt-8 pt-6 border-t border-white/10 flex items-start gap-2 justify-center text-[11px] text-[#71717a] max-w-md mx-auto">
              <Info className="w-4 h-4 shrink-0 mt-0.5" />
              <span>
                This recommendation is an architectural guide to help explore system options. It is not an official benchmark or guarantee. Actual software performance depends on system design and platform configurations.
              </span>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
