/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { ReactNode } from 'react';
import { motion } from 'motion/react';
import {
  staggerContainerVariants,
  fadeSlideUpVariants,
  type MotionCustomProps
} from '../utils/motionVariants';

interface CinematicHeaderProps {
  kicker?: ReactNode;
  headline: ReactNode;
  subtitle?: ReactNode;
  align?: 'center' | 'left';
  as?: 'h1' | 'h2';
  reducedMotion?: boolean;
  className?: string;
  actions?: ReactNode;
}

export const CinematicHeader: React.FC<CinematicHeaderProps> = ({
  kicker,
  headline,
  subtitle,
  align = 'center',
  as = 'h2',
  reducedMotion = false,
  className = '',
  actions
}) => {
  const customProps: MotionCustomProps = { reducedMotion };

  const HeadlineTag = as === 'h1' ? motion.h1 : motion.h2;

  const alignmentClass = align === 'center' ? 'text-center mx-auto' : 'text-left';

  return (
    <motion.div
      variants={staggerContainerVariants}
      custom={customProps}
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true, amount: 0.2 }}
      className={`max-w-3xl ${alignmentClass} ${className}`}
    >
      {/* 1. Kicker / Pillar Identifier */}
      {kicker && (
        <motion.div
          variants={fadeSlideUpVariants}
          custom={customProps}
          className={`flex items-center gap-2 text-xs font-semibold tracking-widest uppercase text-[#ffad42] mb-3.5 ${
            align === 'center' ? 'justify-center' : 'justify-start'
          }`}
        >
          {kicker}
        </motion.div>
      )}

      {/* 2. Primary Cinematic Headline */}
      <HeadlineTag
        variants={fadeSlideUpVariants}
        custom={customProps}
        className={
          as === 'h1'
            ? 'text-4xl sm:text-6xl md:text-7xl font-extrabold tracking-tight text-white mb-5 leading-[1.08] text-balance'
            : 'text-3xl sm:text-5xl font-extrabold tracking-tight text-white mb-4 leading-[1.12] text-balance'
        }
      >
        {headline}
      </HeadlineTag>

      {/* 3. Supporting Editorial Prose */}
      {subtitle && (
        <motion.p
          variants={fadeSlideUpVariants}
          custom={customProps}
          className="text-base sm:text-lg text-[#a1a1aa] leading-relaxed max-w-2xl mx-auto text-balance"
        >
          {subtitle}
        </motion.p>
      )}

      {/* 4. Optional Attached Action / Toggle Controls */}
      {actions && (
        <motion.div
          variants={fadeSlideUpVariants}
          custom={customProps}
          className="mt-8"
        >
          {actions}
        </motion.div>
      )}
    </motion.div>
  );
};
