/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Sparkles, Cpu, Wifi, Zap } from 'lucide-react';
import { CAMPAIGN_DATA } from '../data/campaignConfig';
import { sound } from '../utils/audio';
import { CinematicHeader } from './CinematicHeader';

interface OriginSectionProps {
  onContinueToLights: () => void;
  reducedMotion?: boolean;
}

export const OriginSection: React.FC<OriginSectionProps> = ({
  onContinueToLights,
  reducedMotion = false
}) => {
  // 0: Single Ember, 50: The Division on Workbench, 100: Two Distinct Objects Born
  const [stageProgress, setStageProgress] = useState<number>(50);

  const handleStageSelect = (val: number) => {
    sound.playClick();
    if (val === 100) {
      sound.playCrystalChime(740);
    } else {
      sound.playAmberWarmth(200);
    }
    setStageProgress(val);
  };

  // Interpolation metrics based on progress (0 -> 100)
  const separation = stageProgress / 100; // 0 to 1
  const leftX = 50 - separation * 30; // 50 down to 20
  const rightX = 50 + separation * 30; // 50 up to 80

  return (
    <section
      id="origin"
      className="relative min-h-screen w-full py-28 px-6 sm:px-12 bg-[#08090c] border-t border-white/5 flex flex-col justify-center"
    >
      {/* Background Studio Workbench Vignette */}
      <div className="pointer-events-none absolute inset-0 overflow-hidden" aria-hidden="true">
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[900px] h-[500px] bg-gradient-to-b from-[#ffad42]/10 via-[#ff5500]/5 to-transparent blur-[120px]" />
      </div>

      <div className="relative z-10 max-w-6xl mx-auto w-full">
        {/* Header Block */}
        <CinematicHeader
          className="mb-12 sm:mb-16"
          reducedMotion={reducedMotion}
          kicker={
            <>
              <Cpu className="w-4 h-4" />
              <span>Shared Intel 18A Manufacturing Foundation</span>
            </>
          }
          headline={
            <>
              EVERYTHING BEGINS WITH ONE SPARK<span className="text-[#ffad42]">.</span>
            </>
          }
          subtitle="A shared foundation. A different expression of possibility."
        />

        {/* Interactive Transformation Stage Canvas */}
        <div className="relative rounded-2xl bg-[#121419]/90 border border-white/10 p-6 sm:p-12 shadow-2xl overflow-hidden backdrop-blur-sm">
          {/* Subtle Ambient Workshop Ambient Glow */}
          <div
            className="absolute inset-0 pointer-events-none transition-all duration-700"
            style={{
              background: `radial-gradient(circle at 50% 50%, rgba(255, 173, 66, ${
                0.08 + separation * 0.08
              }) 0%, transparent 70%)`
            }}
          />

          {/* SVG Animated Transformation Workbench */}
          <div className="relative w-full h-72 sm:h-96 flex items-center justify-center">
            <svg
              viewBox="0 0 1000 400"
              className="w-full h-full overflow-visible"
              preserveAspectRatio="xMidYMid meet"
            >
              <defs>
                <linearGradient id="splitGradientLeft" x1="50%" y1="50%" x2="0%" y2="50%">
                  <stop offset="0%" stopColor="#ffad42" />
                  <stop offset="50%" stopColor="#c5e3ff" />
                  <stop offset="100%" stopColor="#eaf5ff" />
                </linearGradient>
                <linearGradient id="splitGradientRight" x1="50%" y1="50%" x2="100%" y2="50%">
                  <stop offset="0%" stopColor="#ffad42" />
                  <stop offset="60%" stopColor="#ff9f22" />
                  <stop offset="100%" stopColor="#ffb45b" />
                </linearGradient>

                <radialGradient id="chandelierGlow" cx="50%" cy="50%" r="50%">
                  <stop offset="0%" stopColor="#ffffff" />
                  <stop offset="40%" stopColor="#cbe5fe" />
                  <stop offset="80%" stopColor="#6bb7ff" stopOpacity="0.4" />
                  <stop offset="100%" stopColor="#08090c" stopOpacity="0" />
                </radialGradient>

                <radialGradient id="lanternGlow" cx="50%" cy="50%" r="50%">
                  <stop offset="0%" stopColor="#ffffff" />
                  <stop offset="40%" stopColor="#ffd48a" />
                  <stop offset="80%" stopColor="#ff9f22" stopOpacity="0.5" />
                  <stop offset="100%" stopColor="#08090c" stopOpacity="0" />
                </radialGradient>

                {/* Filter for glowing light trails */}
                <filter id="bloom" x="-20%" y="-20%" width="140%" height="140%">
                  <feGaussianBlur stdDeviation="6" result="blur" />
                  <feComposite in="SourceGraphic" in2="blur" operator="over" />
                </filter>
              </defs>

              {/* Glassblower's Workbench Baseline Horizon */}
              <line
                x1="80"
                y1="340"
                x2="920"
                y2="340"
                stroke="#272a34"
                strokeWidth="1.5"
                strokeDasharray="4 6"
              />
              <text x="500" y="365" textAnchor="middle" fill="#71717a" fontSize="12" letterSpacing="3">
                ARTISAN WORKBENCH · INTEL 18A MOLECULAR SUBSTRATE
              </text>

              {/* Connecting Bifurcation Paths */}
              {separation > 0.05 && (
                <>
                  {/* Left Path towards Chandelier */}
                  <path
                    d={`M500,180 Q${500 - separation * 140},${180 - separation * 50} ${
                      leftX * 10
                    },180`}
                    fill="none"
                    stroke="url(#splitGradientLeft)"
                    strokeWidth={Math.max(2, 6 - separation * 3)}
                    strokeLinecap="round"
                    filter="url(#bloom)"
                    opacity={separation * 0.9}
                  />

                  {/* Right Path towards Lantern */}
                  <path
                    d={`M500,180 Q${500 + separation * 140},${180 + separation * 50} ${
                      rightX * 10
                    },180`}
                    fill="none"
                    stroke="url(#splitGradientRight)"
                    strokeWidth={Math.max(2, 6 - separation * 3)}
                    strokeLinecap="round"
                    filter="url(#bloom)"
                    opacity={separation * 0.9}
                  />
                </>
              )}

              {/* Wi-Fi 7 & Thunderbolt 4 Emerging Light Trails (when stage >= 50) */}
              {stageProgress >= 40 && (
                <g opacity={Math.min(1, (stageProgress - 40) / 40)} filter="url(#bloom)">
                  {/* Wi-Fi 7 Radiant Waves */}
                  <path
                    d={`M${leftX * 10 - 40},130 Q${leftX * 10 - 70},110 ${leftX * 10 - 100},130`}
                    fill="none"
                    stroke="#a5d8ff"
                    strokeWidth="2"
                    strokeDasharray="3 3"
                    className="animate-pulse"
                  />
                  <path
                    d={`M${rightX * 10 + 40},130 Q${rightX * 10 + 70},110 ${rightX * 10 + 100},130`}
                    fill="none"
                    stroke="#ffd48a"
                    strokeWidth="2"
                    strokeDasharray="3 3"
                    className="animate-pulse"
                  />
                  {/* Thunderbolt 4 Energy Beam */}
                  <path
                    d={`M${leftX * 10},230 L${leftX * 10 - 30},280 L${leftX * 10 - 15},280 L${leftX * 10 - 40},320`}
                    fill="none"
                    stroke="#6bb7ff"
                    strokeWidth="2"
                    strokeLinecap="round"
                  />
                  <path
                    d={`M${rightX * 10},230 L${rightX * 10 + 30},280 L${rightX * 10 + 15},280 L${rightX * 10 + 40},320`}
                    fill="none"
                    stroke="#ffad42"
                    strokeWidth="2"
                    strokeLinecap="round"
                  />
                </g>
              )}

              {/* Left Object / Trail Head: The Chandelier Emergence */}
              <g
                transform={`translate(${leftX * 10}, 180)`}
                style={{ transition: 'transform 0.2s ease-out' }}
              >
                {/* Aura */}
                <circle cx="0" cy="0" r={40 + separation * 30} fill="url(#chandelierGlow)" />

                {/* Chandelier Crystal Prisms appearing as separation increases */}
                {separation > 0.4 ? (
                  <g opacity={separation}>
                    {/* Crystalline facets */}
                    <polygon
                      points="0,-45 28,-15 18,30 -18,30 -28,-15"
                      fill="none"
                      stroke="#eaf5ff"
                      strokeWidth="2"
                      opacity="0.85"
                    />
                    <polygon
                      points="0,-35 18,-10 12,20 -12,20 -18,-10"
                      fill="none"
                      stroke="#a5d8ff"
                      strokeWidth="1.5"
                      opacity="0.7"
                    />
                    {/* Glowing Filaments preview (16 cores) */}
                    {Array.from({ length: 8 }).map((_, i) => {
                      const angle = (i / 8) * Math.PI * 2;
                      const x1 = Math.cos(angle) * 8;
                      const y1 = Math.sin(angle) * 8;
                      const x2 = Math.cos(angle) * 22;
                      const y2 = Math.sin(angle) * 22;
                      return (
                        <line
                          key={i}
                          x1={x1}
                          y1={y1}
                          x2={x2}
                          y2={y2}
                          stroke="#eaf5ff"
                          strokeWidth="2"
                          strokeLinecap="round"
                          opacity="0.9"
                        />
                      );
                    })}
                    {/* NPU Spark (50 TOPS) */}
                    <circle cx="0" cy="0" r="6" fill="#ffffff" filter="url(#bloom)" />
                  </g>
                ) : (
                  <circle cx="0" cy="0" r={16 + separation * 10} fill="#ffad42" />
                )}
              </g>

              {/* Right Object / Trail Head: The Amber Lantern Emergence */}
              <g
                transform={`translate(${rightX * 10}, 180)`}
                style={{ transition: 'transform 0.2s ease-out' }}
              >
                {/* Aura */}
                <circle cx="0" cy="0" r={35 + separation * 25} fill="url(#lanternGlow)" />

                {/* Hand-blown lantern glass appearing as separation increases */}
                {separation > 0.4 ? (
                  <g opacity={separation}>
                    {/* Lantern glass bell shape */}
                    <path
                      d="M-22,-30 C-28, -5 -24, 25 0, 32 C24, 25 28, -5 22, -30 Z"
                      fill="none"
                      stroke="#ffb45b"
                      strokeWidth="2"
                      opacity="0.9"
                    />
                    {/* Brass cap */}
                    <rect x="-14" y="-36" width="28" height="6" rx="2" fill="#d97706" />
                    {/* Glowing Filaments (6 cores) */}
                    {Array.from({ length: 6 }).map((_, i) => {
                      const offset = (i - 2.5) * 6;
                      return (
                        <line
                          key={i}
                          x1={offset}
                          y1="-15"
                          x2={offset}
                          y2="15"
                          stroke="#ffea9f"
                          strokeWidth="2"
                          strokeLinecap="round"
                          opacity="0.9"
                        />
                      );
                    })}
                    {/* NPU Spark (17 TOPS) */}
                    <circle cx="0" cy="0" r="4" fill="#ffffff" filter="url(#bloom)" />
                  </g>
                ) : (
                  <circle cx="0" cy="0" r={16 + separation * 10} fill="#ffad42" />
                )}
              </g>

              {/* Center Origin Node (at low separation) */}
              {separation < 0.3 && (
                <circle
                  cx="500"
                  cy="180"
                  r={24 - separation * 30}
                  fill="#ffffff"
                  filter="url(#bloom)"
                />
              )}
            </svg>
          </div>

          {/* Interactive Scrubber / Stage Controls */}
          <div className="mt-8 pt-6 border-t border-white/10">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4 mb-4">
              <span className="text-xs uppercase tracking-widest text-[#a1a1aa] font-medium">
                Metaphor Evolution Stage
              </span>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleStageSelect(0)}
                  className={`px-3 py-1.5 text-xs font-medium rounded transition-colors cursor-pointer ${
                    stageProgress === 0
                      ? 'bg-white/20 text-white border border-white/30'
                      : 'text-[#a1a1aa] hover:text-white bg-white/5'
                  }`}
                >
                  1. The One Ember
                </button>
                <button
                  onClick={() => handleStageSelect(50)}
                  className={`px-3 py-1.5 text-xs font-medium rounded transition-colors cursor-pointer ${
                    stageProgress === 50
                      ? 'bg-white/20 text-white border border-white/30'
                      : 'text-[#a1a1aa] hover:text-white bg-white/5'
                  }`}
                >
                  2. The Division
                </button>
                <button
                  onClick={() => handleStageSelect(100)}
                  className={`px-3 py-1.5 text-xs font-medium rounded transition-colors cursor-pointer ${
                    stageProgress === 100
                      ? 'bg-white/20 text-white border border-white/30'
                      : 'text-[#a1a1aa] hover:text-white bg-white/5'
                  }`}
                >
                  3. The Two Lights
                </button>
              </div>
            </div>

            {/* Slider input */}
            <div className="relative flex items-center">
              <input
                type="range"
                min="0"
                max="100"
                value={stageProgress}
                onChange={(e) => setStageProgress(Number(e.target.value))}
                className="w-full h-2 bg-[#272a34] rounded-lg appearance-none cursor-pointer accent-[#ffad42]"
                aria-label="Scrub through the ember division animation"
              />
            </div>

            <div className="flex justify-between items-center text-[11px] text-[#71717a] mt-2">
              <span>Shared Intel 18A Ember</span>
              <span>Shaped on the Workbench</span>
              <span>Ultra (Chandelier) & Core (Lantern)</span>
            </div>
          </div>
        </div>

        {/* Foundation Callout Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-10">
          <div className="p-6 rounded-xl bg-[#121419]/60 border border-white/5">
            <div className="flex items-center gap-3 text-white font-semibold text-sm mb-2">
              <Cpu className="w-4 h-4 text-[#ffad42]" />
              <span>Intel 18A Architecture</span>
            </div>
            <p className="text-xs text-[#a1a1aa] leading-relaxed">
              Sub-nanometer precision RibbonFET transistors and PowerVia backside power delivery form the unified physical bedrock of both processor families.
            </p>
          </div>

          <div className="p-6 rounded-xl bg-[#121419]/60 border border-white/5">
            <div className="flex items-center gap-3 text-white font-semibold text-sm mb-2">
              <Wifi className="w-4 h-4 text-[#6bb7ff]" />
              <span>Shared Wi-Fi 7 Trail</span>
            </div>
            <p className="text-xs text-[#a1a1aa] leading-relaxed">
              Ultra-wide 320 MHz channels and Multi-Link Operation (MLO) deliver uninterrupted wireless bandwidth to both creative studios and home desks.
            </p>
          </div>

          <div className="p-6 rounded-xl bg-[#121419]/60 border border-white/5">
            <div className="flex items-center gap-3 text-white font-semibold text-sm mb-2">
              <Zap className="w-4 h-4 text-[#ffb45b]" />
              <span>Thunderbolt™ 4 Pipeline</span>
            </div>
            <p className="text-xs text-[#a1a1aa] leading-relaxed">
              40 Gbps bi-directional throughput enables high-speed external storage, multiple high-res displays, and versatile one-cable connectivity.
            </p>
          </div>
        </div>

        {/* Section Continuation Button */}
        <div className="mt-12 text-center">
          <button
            onClick={() => {
              sound.playClick();
              onContinueToLights();
            }}
            className="px-6 py-3 text-xs uppercase tracking-widest font-semibold text-white bg-white/10 hover:bg-white/15 border border-white/20 rounded transition-colors cursor-pointer"
          >
            Explore The Two Lights Side-By-Side →
          </button>
        </div>
      </div>
    </section>
  );
};
