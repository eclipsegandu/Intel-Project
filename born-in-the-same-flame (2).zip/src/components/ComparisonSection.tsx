/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Cpu, Sparkles, Monitor, Wifi, Zap, Layers, Info } from 'lucide-react';
import { CAMPAIGN_DATA } from '../data/campaignConfig';
import { sound } from '../utils/audio';
import { CinematicHeader } from './CinematicHeader';

interface ComparisonSectionProps {
  reducedMotion?: boolean;
}

export const ComparisonSection: React.FC<ComparisonSectionProps> = ({ reducedMotion = false }) => {
  const [viewMode, setViewMode] = useState<'story' | 'specs'>('story');
  const [activeCategory, setActiveCategory] = useState<'all' | 'cpu' | 'ai' | 'graphics'>('all');
  const [activeFilamentCount, setActiveFilamentCount] = useState<number>(16);

  const ultra = CAMPAIGN_DATA.products.ultra;
  const core = CAMPAIGN_DATA.products.core;

  const handleToggleMode = (mode: 'story' | 'specs') => {
    sound.playClick();
    setViewMode(mode);
  };

  return (
    <section
      id="comparison"
      className="relative min-h-screen w-full py-28 px-6 sm:px-12 bg-[#08090c] border-t border-white/5 flex flex-col justify-center"
    >
      <div className="max-w-7xl mx-auto w-full">
        {/* Section Header */}
        <CinematicHeader
          className="mb-12 sm:mb-16"
          reducedMotion={reducedMotion}
          kicker={
            <>
              <span>Harmonious Architecture</span>
              <span className="text-[#a1a1aa]" aria-hidden="true">·</span>
              <span>Scale & Intent</span>
            </>
          }
          headline={
            <>
              NOT THE SAME LIGHT. NOT THE SAME PURPOSE<span className="text-[#ffad42]">.</span>
            </>
          }
          subtitle="Two distinct paths forged from one flame. Explore how architectural energy expands across physical space."
          actions={
            <div className="inline-flex items-center p-1.5 rounded-xl bg-[#121419] border border-white/10 shadow-lg">
              <button
                onClick={() => handleToggleMode('story')}
                className={`px-5 py-2 text-xs font-semibold tracking-wider uppercase rounded-lg transition-all cursor-pointer ${
                  viewMode === 'story'
                    ? 'bg-[#ffad42] text-[#08090c] shadow-[0_0_20px_rgba(255,173,66,0.4)]'
                    : 'text-[#a1a1aa] hover:text-white'
                }`}
              >
                Show The Story
              </button>
              <button
                onClick={() => handleToggleMode('specs')}
                className={`px-5 py-2 text-xs font-semibold tracking-wider uppercase rounded-lg transition-all cursor-pointer ${
                  viewMode === 'specs'
                    ? 'bg-white text-[#08090c] shadow-[0_0_20px_rgba(255,255,255,0.3)]'
                    : 'text-[#a1a1aa] hover:text-white'
                }`}
              >
                Show The Specs
              </button>
            </div>
          }
        />

        {/* =================================================================== */}
        {/* VIEW 1: THE STORY (Artistic Visual Metaphors) */}
        {/* =================================================================== */}
        {viewMode === 'story' ? (
          <div className="space-y-12">
            {/* Category Filter Pills (Functional Buttons) */}
            <div className="flex items-center justify-center gap-2 flex-wrap text-xs font-medium">
              {[
                { id: 'all', label: 'All Dimensions' },
                { id: 'cpu', label: 'CPU Filaments' },
                { id: 'ai', label: 'NPU Spark' },
                { id: 'graphics', label: 'Graphics Light Spread' }
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => {
                    sound.playClick();
                    setActiveCategory(tab.id as 'all' | 'cpu' | 'ai' | 'graphics');
                  }}
                  className={`px-4 py-2 rounded-lg border transition-all cursor-pointer ${
                    activeCategory === tab.id
                      ? 'border-[#ffad42] text-white bg-[#ffad42]/10'
                      : 'border-white/10 text-[#a1a1aa] hover:border-white/20 hover:text-white'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            {/* COMPARISON A: CPU — 16 Filaments vs 6 Filaments */}
            {(activeCategory === 'all' || activeCategory === 'cpu') && (
              <div className="p-8 sm:p-10 rounded-2xl bg-[#121419]/90 border border-white/10 shadow-xl backdrop-blur-sm">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
                  <div>
                    <div className="flex items-center gap-2 text-xs font-semibold tracking-widest uppercase text-[#ffad42] mb-1">
                      <Cpu className="w-4 h-4" />
                      <span>Dimension 01 · CPU Computing Filaments</span>
                    </div>
                    <h3 className="text-xl sm:text-2xl font-bold text-white">
                      The Thread of Computation
                    </h3>
                  </div>
                  <p className="text-xs text-[#a1a1aa] max-w-md">
                    Filaments channel electrical currents into luminescence. More filaments radiate broader parallel execution; tuned filaments focus energy with thermal calm.
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
                  {/* Chandelier Filaments (16 Cores) */}
                  <div className="p-6 rounded-xl bg-[#08090c]/70 border border-[#c5e3ff]/20">
                    <div className="flex items-center justify-between mb-4">
                      <span className="text-xs font-semibold text-[#c5e3ff] uppercase tracking-wider">
                        {ultra.metaphorName}
                      </span>
                      <span className="text-sm font-bold text-white tabular-nums">
                        Up to 16 Cores
                      </span>
                    </div>

                    {/* Interactive 16 Filament Visualizer */}
                    <div className="h-32 flex items-center justify-between gap-1.5 px-3 bg-black/40 rounded-lg border border-white/5 overflow-hidden">
                      {Array.from({ length: 16 }).map((_, i) => (
                        <div
                          key={i}
                          className="flex-1 flex flex-col items-center justify-end h-full py-3 group cursor-pointer"
                          onMouseEnter={() => sound.playCrystalChime(700 + i * 20)}
                        >
                          <div
                            className="w-full rounded-t-full transition-all duration-300"
                            style={{
                              height: `${60 + Math.sin(i * 0.4) * 35}%`,
                              background: 'linear-gradient(to top, #6bb7ff, #ffffff)',
                              boxShadow: '0 0 10px rgba(165,216,255,0.7)'
                            }}
                          />
                          <span className="text-[9px] text-[#71717a] mt-1 tabular-nums">{i + 1}</span>
                        </div>
                      ))}
                    </div>

                    <p className="text-xs text-[#a1a1aa] mt-4 leading-relaxed">
                      16 interwoven strands capable of rendering heavy multi-track timelines, complex 3D ray-tracing, and sustained compile workloads simultaneously.
                    </p>
                  </div>

                  {/* Lantern Filaments (6 Cores) */}
                  <div className="p-6 rounded-xl bg-[#08090c]/70 border border-[#ffb45b]/20">
                    <div className="flex items-center justify-between mb-4">
                      <span className="text-xs font-semibold text-[#ffb45b] uppercase tracking-wider">
                        {core.metaphorName}
                      </span>
                      <span className="text-sm font-bold text-white tabular-nums">
                        Up to 6 Cores
                      </span>
                    </div>

                    {/* Interactive 6 Filament Visualizer */}
                    <div className="h-32 flex items-center justify-around gap-3 px-6 bg-black/40 rounded-lg border border-white/5 overflow-hidden">
                      {Array.from({ length: 6 }).map((_, i) => (
                        <div
                          key={i}
                          className="flex-1 flex flex-col items-center justify-end h-full py-3 group cursor-pointer max-w-[28px]"
                          onMouseEnter={() => sound.playAmberWarmth(200 + i * 30)}
                        >
                          <div
                            className="w-full rounded-t-full transition-all duration-300 animate-filament"
                            style={{
                              height: `${70 + Math.sin(i * 0.7) * 25}%`,
                              background: 'linear-gradient(to top, #ffad42, #fff4dc)',
                              boxShadow: '0 0 12px rgba(255,173,66,0.85)',
                              animationDelay: `${i * 0.3}s`
                            }}
                          />
                          <span className="text-[9px] text-[#71717a] mt-1 tabular-nums">{i + 1}</span>
                        </div>
                      ))}
                    </div>

                    <p className="text-xs text-[#a1a1aa] mt-4 leading-relaxed">
                      6 disciplined filaments tuned for instant agility, cool thermal comfort, and effortless execution of document creation, browser research, and video meetings.
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* COMPARISON B: AI / NPU — 50 TOPS vs 17 TOPS */}
            {(activeCategory === 'all' || activeCategory === 'ai') && (
              <div className="p-8 sm:p-10 rounded-2xl bg-[#121419]/90 border border-white/10 shadow-xl backdrop-blur-sm">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
                  <div>
                    <div className="flex items-center gap-2 text-xs font-semibold tracking-widest uppercase text-[#ffad42] mb-1">
                      <Sparkles className="w-4 h-4" />
                      <span>Dimension 02 · Neural Processing Unit (NPU)</span>
                    </div>
                    <h3 className="text-xl sm:text-2xl font-bold text-white">
                      The Inner Spark of Intelligence
                    </h3>
                  </div>
                  <p className="text-xs text-[#a1a1aa] max-w-md">
                    Represented as a dedicated, glowing inner spark. Real-world AI utility depends on application frameworks, but relative acceleration reveals how neural models run locally.
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
                  {/* Chandelier NPU (50 TOPS) */}
                  <div className="p-6 rounded-xl bg-[#08090c]/70 border border-[#c5e3ff]/20 flex flex-col items-center text-center">
                    <span className="text-xs font-semibold text-[#c5e3ff] uppercase tracking-wider mb-2">
                      Core Ultra Series 3
                    </span>
                    <div className="text-3xl font-extrabold text-white mb-4 tabular-nums">
                      Up to 50 TOPS
                    </div>

                    {/* Glowing Spark Representation */}
                    <div className="relative w-40 h-40 flex items-center justify-center my-3">
                      <div className="absolute inset-0 rounded-full bg-[#6bb7ff]/20 blur-xl animate-pulse" />
                      <div className="absolute w-28 h-28 rounded-full border border-[#a5d8ff]/40 animate-spin" style={{ animationDuration: '10s' }} />
                      <div className="absolute w-20 h-20 rounded-full border-2 border-dashed border-[#ffffff]/60 animate-spin" style={{ animationDuration: '6s', animationDirection: 'reverse' }} />
                      <div className="w-12 h-12 rounded-full bg-white shadow-[0_0_25px_#a5d8ff] flex items-center justify-center">
                        <Sparkles className="w-6 h-6 text-[#1e40af]" />
                      </div>
                    </div>

                    <p className="text-xs text-[#a1a1aa] mt-3 leading-relaxed">
                      High-throughput neural engine capable of local LLM inference, rapid text-to-image synthesis, neural audio master separation, and real-time smart video mask rotoscoping.
                    </p>
                  </div>

                  {/* Lantern NPU (17 TOPS) */}
                  <div className="p-6 rounded-xl bg-[#08090c]/70 border border-[#ffb45b]/20 flex flex-col items-center text-center">
                    <span className="text-xs font-semibold text-[#ffb45b] uppercase tracking-wider mb-2">
                      Core Series 3
                    </span>
                    <div className="text-3xl font-extrabold text-white mb-4 tabular-nums">
                      Up to 17 TOPS
                    </div>

                    {/* Glowing Spark Representation */}
                    <div className="relative w-40 h-40 flex items-center justify-center my-3">
                      <div className="absolute inset-0 rounded-full bg-[#ffad42]/20 blur-lg animate-pulse" />
                      <div className="absolute w-20 h-20 rounded-full border border-[#ffb45b]/40 animate-spin" style={{ animationDuration: '14s' }} />
                      <div className="w-8 h-8 rounded-full bg-[#ffea9f] shadow-[0_0_20px_#ffad42] flex items-center justify-center">
                        <Sparkles className="w-4 h-4 text-[#92400e]" />
                      </div>
                    </div>

                    <p className="text-xs text-[#a1a1aa] mt-3 leading-relaxed">
                      Quietly accelerates background camera noise removal, automatic face framing, live speech transcription, and smart battery preservation without waking heavy compute engines.
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* COMPARISON C: Graphics — 12 Xe3 Cores vs 2 Xe3 Cores */}
            {(activeCategory === 'all' || activeCategory === 'graphics') && (
              <div className="p-8 sm:p-10 rounded-2xl bg-[#121419]/90 border border-white/10 shadow-xl backdrop-blur-sm">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
                  <div>
                    <div className="flex items-center gap-2 text-xs font-semibold tracking-widest uppercase text-[#ffad42] mb-1">
                      <Monitor className="w-4 h-4" />
                      <span>Dimension 03 · Graphics & Light Spread</span>
                    </div>
                    <h3 className="text-xl sm:text-2xl font-bold text-white">
                      The Breadth of Illumination
                    </h3>
                  </div>
                  <p className="text-xs text-[#a1a1aa] max-w-md">
                    Graphics visualized as illumination across surfaces: an omnidirectional bloom filling an entire creative studio versus an intimate, crisp spotlight over a focused desktop.
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
                  {/* Chandelier: Wide Studio Illumination */}
                  <div className="p-6 rounded-xl bg-[#08090c]/70 border border-[#c5e3ff]/20">
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-xs font-semibold text-[#c5e3ff] uppercase tracking-wider">
                        12 Xe3 Graphics Cores
                      </span>
                      <span className="text-[11px] text-[#a1a1aa]">Whole-Room Radius</span>
                    </div>

                    <div className="relative h-44 rounded-lg bg-black/60 border border-white/5 overflow-hidden flex items-center justify-center p-4">
                      {/* Expansive Ray Spread Graphic */}
                      <div className="absolute inset-0 bg-radial from-[#cbe5fe]/30 via-[#6bb7ff]/10 to-transparent" />
                      <div className="relative z-10 w-full flex items-center justify-around">
                        <div className="text-center p-2 rounded bg-white/5 border border-white/10">
                          <span className="text-[10px] text-[#a5d8ff] block">Display 1</span>
                          <span className="text-xs font-semibold text-white">4K Canvas</span>
                        </div>
                        <div className="text-center p-2 rounded bg-white/5 border border-white/10">
                          <span className="text-[10px] text-[#a5d8ff] block">Display 2</span>
                          <span className="text-xs font-semibold text-white">3D Viewport</span>
                        </div>
                        <div className="text-center p-2 rounded bg-white/5 border border-white/10">
                          <span className="text-[10px] text-[#a5d8ff] block">Display 3</span>
                          <span className="text-xs font-semibold text-white">Video Scope</span>
                        </div>
                      </div>
                    </div>

                    <p className="text-xs text-[#a1a1aa] mt-4 leading-relaxed">
                      Broad light that fills high-framerate displays, hardware-accelerated ray tracing, and intensive visual production tools across expansive multi-monitor setups.
                    </p>
                  </div>

                  {/* Lantern: Focused Desktop Light Pool */}
                  <div className="p-6 rounded-xl bg-[#08090c]/70 border border-[#ffb45b]/20">
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-xs font-semibold text-[#ffb45b] uppercase tracking-wider">
                        2 Xe3 Graphics Cores
                      </span>
                      <span className="text-[11px] text-[#a1a1aa]">Desk-Pool Radius</span>
                    </div>

                    <div className="relative h-44 rounded-lg bg-black/60 border border-white/5 overflow-hidden flex items-center justify-center p-4">
                      {/* Focused Warm Pool Graphic */}
                      <div className="absolute w-44 h-44 rounded-full bg-radial from-[#ffb45b]/40 via-[#ff9f22]/15 to-transparent blur-md" />
                      <div className="relative z-10 text-center p-4 rounded-xl bg-[#08090c]/80 border border-[#ffb45b]/30">
                        <span className="text-[10px] text-[#ffb45b] block uppercase tracking-wider">
                          Dedicated Workspace
                        </span>
                        <span className="text-sm font-semibold text-white">
                          Dual 4K Clarity & Media Engine
                        </span>
                      </div>
                    </div>

                    <p className="text-xs text-[#a1a1aa] mt-4 leading-relaxed">
                      Intentionally focused illumination delivering razor-sharp text clarity, hardware AV1 decode for 4K streams, and seamless external monitor expansion without excess power draw.
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>
        ) : (
          /* =================================================================== */
          /* VIEW 2: THE SPECS (Clean, Accessible Specification Table) */
          /* =================================================================== */
          <div className="rounded-2xl bg-[#121419]/90 border border-white/10 p-6 sm:p-10 shadow-2xl backdrop-blur-sm overflow-x-auto">
            <div className="min-w-[640px]">
              <table className="w-full text-left text-sm border-collapse">
                <thead>
                  <tr className="border-b border-white/10">
                    <th className="py-4 px-4 text-xs font-semibold uppercase tracking-wider text-[#a1a1aa]">
                      Architecture Feature
                    </th>
                    <th className="py-4 px-4 text-sm font-bold text-[#c5e3ff] uppercase tracking-wider">
                      Intel® Core™ Ultra Series 3
                      <span className="block text-[11px] font-normal text-[#a1a1aa] capitalize">
                        (The Crystal Chandelier)
                      </span>
                    </th>
                    <th className="py-4 px-4 text-sm font-bold text-[#ffb45b] uppercase tracking-wider">
                      Intel® Core™ Series 3
                      <span className="block text-[11px] font-normal text-[#a1a1aa] capitalize">
                        (The Amber Lantern)
                      </span>
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5 text-xs sm:text-sm">
                  <tr>
                    <td className="py-4 px-4 font-medium text-white flex items-center gap-2">
                      <Cpu className="w-4 h-4 text-[#ffad42]" />
                      <span>Manufacturing Foundation</span>
                    </td>
                    <td className="py-4 px-4 text-white">
                      Intel 18A Process (Shared)
                    </td>
                    <td className="py-4 px-4 text-white">
                      Intel 18A Process (Shared)
                    </td>
                  </tr>

                  <tr>
                    <td className="py-4 px-4 font-medium text-white">
                      Maximum CPU Cores
                    </td>
                    <td className="py-4 px-4 font-semibold text-white tabular-nums">
                      Up to 16 Cores (16 Filaments)
                    </td>
                    <td className="py-4 px-4 font-semibold text-white tabular-nums">
                      Up to 6 Cores (6 Filaments)
                    </td>
                  </tr>

                  <tr>
                    <td className="py-4 px-4 font-medium text-white">
                      NPU Performance
                    </td>
                    <td className="py-4 px-4 font-semibold text-white tabular-nums">
                      Up to 50 TOPS
                    </td>
                    <td className="py-4 px-4 font-semibold text-white tabular-nums">
                      Up to 17 TOPS
                    </td>
                  </tr>

                  <tr>
                    <td className="py-4 px-4 font-medium text-white">
                      Graphics Architecture
                    </td>
                    <td className="py-4 px-4 text-white">
                      Up to 12 Xe3 Graphics Cores
                    </td>
                    <td className="py-4 px-4 text-white">
                      Up to 2 Xe3 Graphics Cores
                    </td>
                  </tr>

                  <tr>
                    <td className="py-4 px-4 font-medium text-white">
                      Wireless Connectivity
                    </td>
                    <td className="py-4 px-4 text-white">
                      Wi-Fi 7 (Up to 5 Gbps)
                    </td>
                    <td className="py-4 px-4 text-white">
                      Wi-Fi 7 (Up to 5 Gbps)
                    </td>
                  </tr>

                  <tr>
                    <td className="py-4 px-4 font-medium text-white">
                      I/O Pipeline
                    </td>
                    <td className="py-4 px-4 text-white">
                      Thunderbolt™ 4 (40 Gbps)
                    </td>
                    <td className="py-4 px-4 text-white">
                      Thunderbolt™ 4 (40 Gbps)
                    </td>
                  </tr>

                  <tr>
                    <td className="py-4 px-4 font-medium text-white">
                      Intended Workspace
                    </td>
                    <td className="py-4 px-4 text-[#a1a1aa]">
                      The Creator's Studio: 3D, Video, Gaming, Neural Rendering
                    </td>
                    <td className="py-4 px-4 text-[#a1a1aa]">
                      The Study Desk: Research, Video Meetings, Writing, Daily Tasks
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Campaign Data Disclaimer */}
        <div className="mt-8 flex items-start gap-3 p-4 rounded-xl bg-white/[0.02] border border-white/5 text-[11px] text-[#71717a] leading-relaxed">
          <Info className="w-4 h-4 text-[#a1a1aa] shrink-0 mt-0.5" />
          <p>{CAMPAIGN_DATA.disclaimer}</p>
        </div>
      </div>
    </section>
  );
};
