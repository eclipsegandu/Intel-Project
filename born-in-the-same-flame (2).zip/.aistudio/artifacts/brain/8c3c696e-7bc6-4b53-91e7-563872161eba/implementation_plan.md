# Shared Framer Motion Variant Configuration Architecture

Create a centralized, type-safe Framer Motion variant configuration file (`src/utils/motionVariants.ts`) exporting reusable static variant objects that support custom props for `reducedMotion`, ensuring `transition={{ duration: reducedMotion ? 0 : 0.8 }}` and consistent luxury easing across all pages and components.

## User Review & Critical Decisions

> [!IMPORTANT]
> The following user preferences were confirmed during clarification:
> - **Export Pattern**: Static variant objects utilizing Framer Motion's `custom` prop pattern (e.g. `(custom: MotionCustomProps) => TargetAndTransition`), enabling dynamic parameterization per element.
> - **Preset Scope**: Comprehensive animation library including:
>   1. Staggered container reveals (`staggerContainerVariants`)
>   2. Staggered text & headline reveals (`fadeSlideUpVariants`) with `duration: reducedMotion ? 0 : 0.8`
>   3. Interactive card reveals (`cardRevealVariants`)
>   4. Scale fades (`scaleFadeVariants`)
>   5. Glowing spark / ember pulses (`emberPulseVariants`)
> - **Motion Accessibility**: Universal `reducedMotion` zero-duration handling (`duration: reducedMotion ? 0 : 0.8`) across all presets.

## 1. Overview & Core Concept

- **What It Delivers**: A single authoritative animation registry for all motion effects across the "Born in the Same Flame" application.
- **Why It Matters**: Prevents duplicate animation logic in individual components, ensures identical cubic-bezier luxury settling physics (`[0.16, 1, 0.3, 1]`), and guarantees accessible reduced-motion support.

## 2. User Experience & Visual Design

- **Presets Included**:
  - `staggerContainerVariants`: Orchestrates children with 160ms stagger interval and 80ms delay.
  - `fadeSlideUpVariants`: Smooth 28px vertical translation with opacity fade-in over 0.8s (`reducedMotion ? 0 : 0.8`).
  - `cardRevealVariants`: Subtle 20px rise with micro-scale settling (0.98 -> 1.0) for studio and desk workspace cards.
  - `scaleFadeVariants`: Balanced depth fade for modals and interactive callouts.
  - `emberPulseVariants`: Gentle organic atmospheric breathing for sparks and glowing filaments.

## 3. Key Product Decisions & Trade-Offs

- **Dynamic Custom Prop vs Factory Functions**:
  - *Chosen Approach*: Static `Variants` objects leveraging `custom?: { reducedMotion?: boolean; duration?: number; delay?: number }`.
  - *Why*: Conforms directly to Framer Motion's canonical declarative API, allowing parent `custom={{ reducedMotion }}` to cascade down through variant child trees automatically.
- **Strict TypeScript Typing**:
  - *Chosen Approach*: Explicitly typed as `Variants` from `motion/react` with const tuples `[0.16, 1, 0.3, 1] as const`.
  - *Why*: Eliminates TypeScript `Easing[]` type mismatches at compile time.

## 4. Technical Architecture & Component Structure

```
┌─────────────────────────────────────────────────────────────┐
│                 src/utils/motionVariants.ts                 │
│         (Authoritative static Motion variant registry)       │
├─────────────────────────────────────────────────────────────┤
│  • staggerContainerVariants(custom)                         │
│  • fadeSlideUpVariants(custom) [duration: 0 / 0.8s]         │
│  • cardRevealVariants(custom)                               │
│  • scaleFadeVariants(custom)                                │
│  • emberPulseVariants(custom)                               │
│  • MOTION_EASE = [0.16, 1, 0.3, 1]                          │
└───────────────┬─────────────────────────────┬───────────────┘
                │                             │
                ▼                             ▼
┌───────────────────────────────┐   ┌───────────────────────────────┐
│     CinematicHeader.tsx       │   │   Interactive Section Views   │
│  (Imports & applies shared    │   │  (Chandelier, Lantern, Cards  │
│   stagger & fadeSlideUp)      │   │   Timeline, Quiz Options)     │
└───────────────────────────────┘   └───────────────────────────────┘
```

### Verification & Testing Plan

1. **Static Analysis & Type Checking**: Run `tsc --noEmit` via `lint_applet` to verify `Variants` typing and custom prop signatures.
2. **Bundle Build Verification**: Run `compile_applet` to ensure seamless Vite compilation.
3. **Runtime Animation Check**: Validate that section headlines smoothly reveal with `0.8s` duration on normal motion and instantly snap with `0s` duration when `reducedMotion` is enabled.
